// =================================================================================================
//  ImageSearchDLL - Ultra-Fast Image Search 
//  Author: Dao Van Trong - TRONG.PRO
//  Architecture: C++14 (Windows XP SP3 - Windows 11)
//  Toolset: v141_xp | Auto-detects OS version and architecture (x86/x64)
//  Licensed under the MIT License. See LICENSE file for details.
// =================================================================================================

#pragma managed(push, off)
#define NOMINMAX

// Required for SHCreateDirectoryExW in shlwapi.h
#ifndef _WIN32_IE
#define _WIN32_IE 0x0500
#endif

#ifndef _WIN32_WINNT
#define _WIN32_WINNT 0x0502
#endif

#include <windows.h>
#include <shlwapi.h>
#include <objidl.h>
// Note: shellscalingapi.h may not be available in older SDKs
// We'll use dynamic loading to avoid compile-time dependency

// Include <algorithm> before GDI+ to provide min/max when NOMINMAX is defined
#include <algorithm>

// Bring std::min and std::max into global namespace for GDI+ compatibility
using std::min;
using std::max;

// Suppress known GDI+ header warnings in Windows 7.1A SDK
#pragma warning(push)
#pragma warning(disable: 4458) // declaration hides class member
#pragma warning(disable: 4459) // declaration hides global declaration
#pragma warning(disable: 4596) // illegal qualified name in member declaration

#include <gdiplus.h>

#pragma warning(pop)
#include <string>
#include <vector>
#include <fstream>
#include <memory>
#include <thread>
#include <future>
#include <mutex>
#include <atomic>
#include <unordered_map>
#include <chrono>
#include <sstream>
#include <iomanip>
#include <cwctype>
#include <cmath>
#include <cstring>
#include <deque>

#pragma comment(lib, "shlwapi.lib")

#ifdef _WIN64
#include <immintrin.h>
#else
#include <emmintrin.h>
#endif
#include <intrin.h>

#ifdef _MSC_VER
#pragma comment(lib, "kernel32.lib")
#pragma comment(lib, "user32.lib")
#pragma comment(lib, "gdi32.lib")
#pragma comment(lib, "gdiplus.lib")
#pragma comment(lib, "shell32.lib")
#pragma comment(lib, "ole32.lib")
#pragma comment(lib, "oleaut32.lib")
#pragma comment(lib, "uuid.lib")
#endif

// ============================================================================
// Windows Version Detection System
// ============================================================================
// Windows 11 Detection:
//   Windows 11 has same major.minor version as Windows 10 (10.0)
//   Distinction is based on build number:
//   - Windows 10: Build 10240-19045 (builds < 22000)
//   - Windows 11: Build 22000+ (initial release: 22000)
// ============================================================================
struct WindowsVersion {
	DWORD major;
	DWORD minor;
	DWORD build;
	bool isXP;
	bool isVista;
	bool isWin7;
	bool isWin8;
	bool isWin8_1;
	bool isWin10;       // Windows 10 (build < 22000)
	bool isWin11Plus;   // Windows 11+ (build >= 22000)
	bool isWin10Plus;   // DEPRECATED: Use isWin10 || isWin11Plus (kept for compatibility)
};

static WindowsVersion g_win_ver = {0};
static std::once_flag g_win_ver_init_flag;

void DetectWindowsVersion() {
	std::call_once(g_win_ver_init_flag, []() {
		ZeroMemory(&g_win_ver, sizeof(g_win_ver));
		
		// Use RtlGetVersion for accurate version detection
		typedef LONG(WINAPI* PFN_RtlGetVersion)(PRTL_OSVERSIONINFOW);
		HMODULE hNtdll = GetModuleHandleW(L"ntdll.dll");
		
		if (hNtdll) {
			auto pRtlGetVersion = (PFN_RtlGetVersion)GetProcAddress(hNtdll, "RtlGetVersion");
			if (pRtlGetVersion) {
				RTL_OSVERSIONINFOW osvi = {0};
				osvi.dwOSVersionInfoSize = sizeof(osvi);
				if (pRtlGetVersion(&osvi) == 0) {
					g_win_ver.major = osvi.dwMajorVersion;
					g_win_ver.minor = osvi.dwMinorVersion;
					g_win_ver.build = osvi.dwBuildNumber;
				}
			}
		}
		
		// Fallback to GetVersionEx if RtlGetVersion fails
		if (g_win_ver.major == 0) {
			OSVERSIONINFOW osvi = {0};
			osvi.dwOSVersionInfoSize = sizeof(osvi);
			#pragma warning(push)
			#pragma warning(disable: 4996) // GetVersionEx deprecated
			if (GetVersionExW(&osvi)) {
				g_win_ver.major = osvi.dwMajorVersion;
				g_win_ver.minor = osvi.dwMinorVersion;
				g_win_ver.build = osvi.dwBuildNumber;
			}
			#pragma warning(pop)
		}
		
		// Set version flags
		g_win_ver.isXP = (g_win_ver.major == 5 && g_win_ver.minor >= 1);
		g_win_ver.isVista = (g_win_ver.major == 6 && g_win_ver.minor == 0);
		g_win_ver.isWin7 = (g_win_ver.major == 6 && g_win_ver.minor == 1);
		g_win_ver.isWin8 = (g_win_ver.major == 6 && g_win_ver.minor == 2);
		g_win_ver.isWin8_1 = (g_win_ver.major == 6 && g_win_ver.minor == 3);
		
		// Windows 10/11 detection based on build number
		// Windows 11 starts at build 22000 (released Oct 2021)
		if (g_win_ver.major >= 10) {
			if (g_win_ver.build >= 22000) {
				g_win_ver.isWin11Plus = true;
				g_win_ver.isWin10 = false;
			} else {
				g_win_ver.isWin11Plus = false;
				g_win_ver.isWin10 = true;
			}
			g_win_ver.isWin10Plus = true;  // Compatibility flag
		} else {
			g_win_ver.isWin10 = false;
			g_win_ver.isWin11Plus = false;
			g_win_ver.isWin10Plus = false;
		}
	});
}

// ============================================================================
// C++14 Compatibility Utilities (Replacement for C++17 features)
// ============================================================================

// Replacement for std::optional<T>
template<typename T>
class Optional {
private:
	alignas(T) unsigned char storage[sizeof(T)];
	bool has_value_;
	
	T* ptr() { return reinterpret_cast<T*>(&storage[0]); }
	const T* ptr() const { return reinterpret_cast<const T*>(&storage[0]); }
	
public:
	Optional() : has_value_(false) {}
	
	Optional(const T& value) : has_value_(true) {
		new (&storage[0]) T(value);
	}
	
	Optional(T&& value) : has_value_(true) {
		new (&storage[0]) T(std::move(value));
	}
	
	Optional(const Optional& other) : has_value_(other.has_value_) {
		if (has_value_) {
			new (&storage[0]) T(*other.ptr());
		}
	}
	
	Optional(Optional&& other) noexcept : has_value_(other.has_value_) {
		if (has_value_) {
			new (&storage[0]) T(std::move(*other.ptr()));
			other.reset();
		}
	}
	
	~Optional() {
		reset();
	}
	
	Optional& operator=(const Optional& other) {
		if (this != &other) {
			reset();
			has_value_ = other.has_value_;
			if (has_value_) {
				new (&storage[0]) T(*other.ptr());
			}
		}
		return *this;
	}
	
	Optional& operator=(Optional&& other) noexcept {
		if (this != &other) {
			reset();
			has_value_ = other.has_value_;
			if (has_value_) {
				new (&storage[0]) T(std::move(*other.ptr()));
				other.reset();
			}
		}
		return *this;
	}
	
	explicit operator bool() const { return has_value_; }
	bool has_value() const { return has_value_; }
	
	T& operator*() { return *ptr(); }
	const T& operator*() const { return *ptr(); }
	
	T* operator->() { return ptr(); }
	const T* operator->() const { return ptr(); }
	
	void reset() {
		if (has_value_) {
			ptr()->~T();
			has_value_ = false;
		}
	}
};

template<typename T>
Optional<typename std::decay<T>::type> make_optional(T&& value) {
	return Optional<typename std::decay<T>::type>(std::forward<T>(value));
}

// Replacement for std::clamp
template<typename T>
inline T clamp_value(const T& val, const T& min_val, const T& max_val) {
	return (val < min_val) ? min_val : (val > max_val) ? max_val : val;
}

// C++14 compatible mutex (XP compatible)
using SharedMutex = std::mutex;
using SharedLock = std::lock_guard<std::mutex>;
using UniqueLock = std::unique_lock<std::mutex>;

// Filesystem replacement using WinAPI
namespace FileSystem {
	inline bool exists(const std::wstring& path) {
		return PathFileExistsW(path.c_str()) != FALSE;
	}
	
	inline bool create_directories(const std::wstring& path) {
		// XP-compatible: Create directory recursively
		// Manual implementation because SHCreateDirectoryExW may not be available in v141_xp SDK
		if (path.empty()) return false;
		if (exists(path)) return true;
		
		// Find parent directory
		size_t pos = path.find_last_of(L"\\/");
		if (pos != std::wstring::npos && pos > 0) {
			std::wstring parent = path.substr(0, pos);
			// Recursively create parent
			if (!exists(parent)) {
				if (!create_directories(parent)) {
					return false;
				}
			}
		}
		
		// Create this directory
		return CreateDirectoryW(path.c_str(), nullptr) != FALSE || 
		       GetLastError() == ERROR_ALREADY_EXISTS;
	}
	
	inline bool remove(const std::wstring& path) {
		return DeleteFileW(path.c_str()) != FALSE;
	}
	
	inline std::wstring get_filename(const std::wstring& path) {
		const wchar_t* filename = PathFindFileNameW(path.c_str());
		return filename ? filename : L"";
	}
	
	inline std::wstring canonical(const std::wstring& path) {
		wchar_t buffer[MAX_PATH];
		if (GetFullPathNameW(path.c_str(), MAX_PATH, buffer, nullptr) > 0) {
			return buffer;
		}
		return path;
	}
	
	// Simple directory iterator for cache cleanup
	struct DirectoryEntry {
		std::wstring path;
		bool is_file;
	};
	
	inline std::vector<DirectoryEntry> directory_iterator(const std::wstring& dir) {
		std::vector<DirectoryEntry> entries;
		std::wstring search_path = dir;
		if (search_path.back() != L'\\') search_path += L'\\';
		search_path += L"*";
		
		WIN32_FIND_DATAW ffd;
		HANDLE hFind = FindFirstFileW(search_path.c_str(), &ffd);
		
		if (hFind != INVALID_HANDLE_VALUE) {
			do {
				if (wcscmp(ffd.cFileName, L".") != 0 && wcscmp(ffd.cFileName, L"..") != 0) {
					DirectoryEntry entry;
					entry.path = dir;
					if (entry.path.back() != L'\\') entry.path += L'\\';
					entry.path += ffd.cFileName;
					entry.is_file = !(ffd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY);
					entries.push_back(entry);
				}
			} while (FindNextFileW(hFind, &ffd) != 0);
			FindClose(hFind);
		}
		
		return entries;
	}
}

#define MAX_MATCHES 1024
#define MAX_CACHED_BITMAPS 100
#define MAX_CACHED_LOCATIONS 100
#define CACHE_MISS_THRESHOLD 3
#define MUTEX_RETRY_COUNT 3
#define MUTEX_RETRY_BASE_MS 100
#define MAX_RESULT_STRING_LENGTH 262144

static std::atomic<int> g_pixel_pool_size{ 50 };

using namespace Gdiplus;

std::wstring FormatFloat(float value, int precision = 2) {
	std::wstringstream ss;
	ss << std::fixed << std::setprecision(precision) << value;
	std::wstring result = ss.str();
	// Remove trailing zeros and redundant decimal point
	result.erase(result.find_last_not_of(L"0") + 1);
	if (result.back() == L'.') {
		result.pop_back();
	}
	return result;
}

int CalculateOptimalPoolSize() {
	MEMORYSTATUSEX memStatus;
	memStatus.dwLength = sizeof(memStatus);
	if (GlobalMemoryStatusEx(&memStatus)) {
		DWORDLONG totalRAM_GB = memStatus.ullTotalPhys / (1024ULL * 1024ULL * 1024ULL);
		int poolSize = static_cast<int>(std::min(100ULL, totalRAM_GB * 5));
		return std::max(50, poolSize);
	}
	return 50;
}

inline int ComputeAlphaThreshold(bool transparent_enabled, int tolerance) {
	if (!transparent_enabled) return 0;
	if (tolerance <= 0) return 255;
	int thresh = 255 - (tolerance * 255 / 255);
	return clamp_value(thresh, 0, 255);
}

#ifdef _MSC_VER
#define SIMD_ALIGNMENT 64
inline void* AlignedAlloc(size_t size, size_t alignment) {
	return _aligned_malloc(size, alignment);
}
inline void AlignedFree(void* ptr) {
	_aligned_free(ptr);
}
#else
#define SIMD_ALIGNMENT 64
inline void* AlignedAlloc(size_t size, size_t alignment) {
	void* ptr = nullptr;
	if (posix_memalign(&ptr, alignment, size) != 0) {
		return nullptr;
	}
	return ptr;
}
inline void AlignedFree(void* ptr) {
	free(ptr);
}
#endif

template<typename T>
struct AlignedAllocator {
	using value_type = T;

	AlignedAllocator() = default;
	template<typename U>
	AlignedAllocator(const AlignedAllocator<U>&) {}

	T* allocate(size_t n) {
		void* ptr = AlignedAlloc(n * sizeof(T), SIMD_ALIGNMENT);
		if (!ptr) {
			return nullptr;
		}
		return static_cast<T*>(ptr);
	}

	void deallocate(T* ptr, size_t) {
		AlignedFree(ptr);
	}

	template<typename U>
	bool operator==(const AlignedAllocator<U>&) const { return true; }
	template<typename U>
	bool operator!=(const AlignedAllocator<U>&) const { return false; }
};

bool WaitForMutexWithRetry(HANDLE hMutex, int retryCount = MUTEX_RETRY_COUNT) {
	for (int attempt = 0; attempt < retryCount; ++attempt) {
		DWORD timeout = MUTEX_RETRY_BASE_MS * (1 << attempt);
		DWORD result = WaitForSingleObject(hMutex, timeout);

		if (result == WAIT_OBJECT_0 || result == WAIT_ABANDONED) {
			return true;
		}
	}
	return false;
}

class ScopedMutex {
public:
	ScopedMutex(HANDLE hMutex) : m_hMutex(hMutex), m_locked(false) {
		if (m_hMutex) {
			m_locked = WaitForMutexWithRetry(m_hMutex);
		}
	}

	~ScopedMutex() {
		if (m_locked && m_hMutex) {
			ReleaseMutex(m_hMutex);
		}
	}

	bool IsLocked() const {
		return m_locked;
	}

	ScopedMutex(const ScopedMutex&) = delete;
	ScopedMutex& operator=(const ScopedMutex&) = delete;

private:
	HANDLE m_hMutex;
	bool m_locked;
};

ULONG_PTR g_gdiplusToken = 0;
std::once_flag g_gdiplus_init_flag;

void InitializeGdiplus() {
	std::call_once(g_gdiplus_init_flag, []() {
		GdiplusStartupInput gdiplusStartupInput;
		Status status = GdiplusStartup(&g_gdiplusToken, &gdiplusStartupInput, nullptr);
		if (status != Ok) {
			// GDI+ initialization failed - set token to 0 for safety
			// Note: std::call_once will NOT retry, so this is permanent failure
			g_gdiplusToken = 0;
		}
		});
}

#ifdef _WIN64
std::atomic<bool> g_is_avx2_supported{ false };
std::atomic<bool> g_is_avx512_supported{ false };
#else
std::atomic<bool> g_is_sse2_supported{ false };
#endif

std::once_flag g_feature_detection_flag;

uint64_t SafeGetXCR0() {
	uint64_t xcr0 = 0;
#ifdef _MSC_VER
	__try {
#if defined(_XCR_XFEATURE_ENABLED_MASK)
		xcr0 = _xgetbv(_XCR_XFEATURE_ENABLED_MASK);
#else
		xcr0 = _xgetbv(0);
#endif
	}
	__except (EXCEPTION_EXECUTE_HANDLER) {
		xcr0 = 0;
	}
#elif defined(__GNUC__) || defined(__clang__)
	try {
		unsigned int eax = 0, edx = 0;
		__asm__ volatile("xgetbv" : "=a"(eax), "=d"(edx) : "c"(0) : );
		xcr0 = (static_cast<uint64_t>(edx) << 32) | eax;
	}
	catch (...) {
		xcr0 = 0;
	}
#endif
	return xcr0;
}

void DetectCpuFeatures() {
	int cpuInfo[4] = { 0 };
	__cpuid(cpuInfo, 0);
	int maxLeaf = cpuInfo[0];

	if (maxLeaf < 1) {
#ifdef _WIN64
		g_is_avx2_supported.store(false, std::memory_order_relaxed);
		g_is_avx512_supported.store(false, std::memory_order_relaxed);
#else
		g_is_sse2_supported.store(false, std::memory_order_relaxed);
#endif
		return;
	}

	int regs1[4] = { 0 };
	__cpuid(regs1, 1);

#ifdef _WIN64
	bool osxsave = (regs1[2] & (1 << 27)) != 0;
	bool avx_os_support = false;

	if (osxsave) {
		uint64_t xcr0 = SafeGetXCR0();
		if ((xcr0 & 0x6ULL) == 0x6ULL) {
			avx_os_support = true;
		}
	}

	bool has_avx2 = false;
	bool has_avx512 = false;

	if (avx_os_support && maxLeaf >= 7) {
		int regs7[4] = { 0 };
		__cpuidex(regs7, 7, 0);
		has_avx2 = (regs7[1] & (1 << 5)) != 0;
		const int avx512_mask = (1 << 16) | (1 << 17) | (1 << 21) | (1 << 30) | (1 << 31);
		has_avx512 = (regs7[1] & avx512_mask) == avx512_mask;
	}

	g_is_avx2_supported.store(has_avx2, std::memory_order_relaxed);
	g_is_avx512_supported.store(has_avx512, std::memory_order_relaxed);
#else
	bool has_sse2 = (regs1[3] & (1 << 26)) != 0;
	g_is_sse2_supported.store(has_sse2, std::memory_order_relaxed);
#endif
}

void DetectFeatures() {
	DetectCpuFeatures();
}

enum class ErrorCode : int {
	Success = 0,
	InvalidPath = -1,
	FailedToLoadImage = -2,
	FailedToGetScreenDC = -3,
	InvalidSearchRegion = -4,
	InvalidParameters = -5,
	InvalidSourceBitmap = -6,
	InvalidTargetBitmap = -7,
	ResultTooLarge = -9,
	InvalidMonitor = -10
};

const wchar_t* GetErrorMessage(ErrorCode code) {
	switch (code) {
	case ErrorCode::InvalidPath: return L"Invalid path or image format";
	case ErrorCode::FailedToLoadImage: return L"Failed to load image from file";
	case ErrorCode::FailedToGetScreenDC: return L"Failed to get screen device context or get valid Source pixels";
	case ErrorCode::InvalidSearchRegion: return L"Invalid search region specified";
	case ErrorCode::InvalidParameters: return L"Invalid parameters provided";
	case ErrorCode::InvalidSourceBitmap: return L"Invalid Source (source) bitmap";
	case ErrorCode::InvalidTargetBitmap: return L"Invalid Target (target) bitmap";
	case ErrorCode::ResultTooLarge: return L"Result String Too Large";
	case ErrorCode::InvalidMonitor: return L"Invalid monitor index";
	default: return L"Unknown error";
	}
}

// OS-aware DPI Awareness (Windows 10+ only, ignored on XP/Vista/7)
class ScopedDpiAwareness {
public:
    ScopedDpiAwareness() : m_prevContext(nullptr) {
        DetectWindowsVersion();
        
        // Only use DPI awareness on Windows 10+ (SetThreadDpiAwarenessContext requires Win10)
        if (!g_win_ver.isWin10Plus) {
            return;
        }

        // Use HANDLE instead of DPI_AWARENESS_CONTEXT (not in Win7.1A SDK)
        typedef HANDLE(WINAPI* PFN_SetThreadDpiAwarenessContext)(HANDLE);
        typedef HANDLE(WINAPI* PFN_GetThreadDpiAwarenessContext)();

        HMODULE hUser = GetModuleHandleW(L"user32.dll");
        if (hUser) {
            auto pSetThreadCtx = (PFN_SetThreadDpiAwarenessContext)GetProcAddress(hUser, "SetThreadDpiAwarenessContext");
            auto pGetThreadCtx = (PFN_GetThreadDpiAwarenessContext)GetProcAddress(hUser, "GetThreadDpiAwarenessContext");
            
            if (pSetThreadCtx && pGetThreadCtx) {
                m_prevContext = pGetThreadCtx();
                // -3 = DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE (Win10 1607+)
                pSetThreadCtx((HANDLE)-3);
            }
        }
    }

    ~ScopedDpiAwareness() {
        if (m_prevContext && g_win_ver.isWin10Plus) {
            typedef HANDLE(WINAPI* PFN_SetThreadDpiAwarenessContext)(HANDLE);
            HMODULE hUser = GetModuleHandleW(L"user32.dll");
            if (hUser) {
                auto pSetThreadCtx = (PFN_SetThreadDpiAwarenessContext)GetProcAddress(hUser, "SetThreadDpiAwarenessContext");
                if (pSetThreadCtx) {
                    pSetThreadCtx(m_prevContext);
                }
            }
        }
    }

private:
    HANDLE m_prevContext;  // Use HANDLE instead of DPI_AWARENESS_CONTEXT
};

inline std::wstring FormatError(ErrorCode code) {
	return L"{" + std::to_wstring(static_cast<int>(code)) + L"}[]<" + GetErrorMessage(code) + L">";
}

// ============================================================================
// HELPER: UnpremultiplyAlpha
// ============================================================================
// Description:
//   Converts premultiplied alpha to straight alpha for accurate color values.
//   Reduces code duplication across LoadImageFromFile_GDI, ScaleBitmap_GDI,
//   and GetBitmapPixels_GDI functions.
//
// Parameters:
//   r, g, b - Color components (0-255, premultiplied)
//   a       - Alpha component (0-255)
//
// Returns:
//   COLORREF with unpremultiplied RGB and alpha in ABGR format
// ============================================================================
inline COLORREF UnpremultiplyAlpha(BYTE r, BYTE g, BYTE b, BYTE a) {
	if (a != 0 && a != 255) {
		float invA = 255.0f / static_cast<float>(a);
		int ur = static_cast<int>(std::round(r * invA));
		int ug = static_cast<int>(std::round(g * invA));
		int ub = static_cast<int>(std::round(b * invA));
		r = static_cast<BYTE>(clamp_value(ur, 0, 255));
		g = static_cast<BYTE>(clamp_value(ug, 0, 255));
		b = static_cast<BYTE>(clamp_value(ub, 0, 255));
	}
	// Return in ABGR format (internal format)
	return (a << 24) | (b << 16) | (g << 8) | r;
}

// ============================================================================
// HELPER: PremultiplyAlpha
// ============================================================================
// Description:
//   Converts straight alpha to premultiplied alpha for GDI+ rendering.
//   Premultiplication means: RGB_out = RGB_in * (Alpha / 255)
//   Used when converting internal format to GDI+ ARGB format.
//
// Parameters:
//   pixel - COLORREF in ABGR format (internal, straight alpha)
//
// Returns:
//   DWORD in ARGB format (GDI+) with premultiplied RGB
//
// CRITICAL FIX: Previous version was doing UNPREMULTIPLY (division) instead of
//               PREMULTIPLY (multiplication), causing wrong colors when scaling.
// ============================================================================
inline DWORD PremultiplyAlpha(COLORREF pixel) {
	BYTE a = (pixel >> 24) & 0xFF;
	BYTE b = (pixel >> 16) & 0xFF;
	BYTE g = (pixel >> 8) & 0xFF;
	BYTE r = pixel & 0xFF;
	
	// Premultiply: RGB *= (A/255)
	if (a != 0 && a != 255) {
		float alpha_factor = static_cast<float>(a) / 255.0f;
		int pr = static_cast<int>(std::round(r * alpha_factor));
		int pg = static_cast<int>(std::round(g * alpha_factor));
		int pb = static_cast<int>(std::round(b * alpha_factor));
		r = static_cast<BYTE>(clamp_value(pr, 0, 255));
		g = static_cast<BYTE>(clamp_value(pg, 0, 255));
		b = static_cast<BYTE>(clamp_value(pb, 0, 255));
	} else if (a == 0) {
		// Fully transparent: RGB should be 0
		r = g = b = 0;
	}
	// Return in ARGB format for GDI+
	return (a << 24) | (r << 16) | (g << 8) | b;
}

// ============================================================================
// HELPER: CreateMouseInput
// ============================================================================
// Description:
//   Creates and initializes a mouse INPUT structure for SendInput.
//   Reduces code duplication in mouse movement functions.
//
// Parameters:
//   x, y - Screen coordinates
//   flags - Mouse event flags (MOUSEEVENTF_MOVE, etc.)
//
// Returns:
//   Initialized INPUT structure
// ============================================================================
inline INPUT CreateMouseInput(int x, int y, DWORD flags) {
	INPUT input;
	ZeroMemory(&input, sizeof(INPUT));
	input.type = INPUT_MOUSE;
	
	// Convert to absolute coordinates if needed
	if (flags & MOUSEEVENTF_ABSOLUTE) {
		LONG ax = 0, ay = 0;
		LONG64 screenWidth = GetSystemMetrics(SM_CXVIRTUALSCREEN);
		LONG64 screenHeight = GetSystemMetrics(SM_CYVIRTUALSCREEN);
		if (screenWidth <= 0) screenWidth = 1;
		if (screenHeight <= 0) screenHeight = 1;
		
		LONG64 ax_temp = (static_cast<LONG64>(x) * 65535LL) / screenWidth;
		LONG64 ay_temp = (static_cast<LONG64>(y) * 65535LL) / screenHeight;
		
		ax = static_cast<LONG>(ax_temp);
		ay = static_cast<LONG>(ay_temp);
		
		input.mi.dx = ax;
		input.mi.dy = ay;
	} else {
		input.mi.dx = x;
		input.mi.dy = y;
	}
	
	input.mi.dwFlags = flags;
	input.mi.dwExtraInfo = 0;
	
	return input;
}

struct PixelBufferPool;
extern PixelBufferPool g_pixel_pool;

struct PixelBuffer {
	std::vector<COLORREF> pixels;
	int width = 0;
	int height = 0;
	bool has_alpha = false;
	bool owns_memory = true;

	bool IsValid() const {
		return width > 0 && height > 0 && pixels.size() == static_cast<size_t>(width * height);
	}

	~PixelBuffer();

	PixelBuffer() = default;
	PixelBuffer(const PixelBuffer&) = delete;
	PixelBuffer& operator=(const PixelBuffer&) = delete;
	PixelBuffer(PixelBuffer&& other) noexcept;
	PixelBuffer& operator=(PixelBuffer&& other) noexcept;
};

struct MatchResult {
	int x, y, w, h;
	float scale = 1.0f;
	std::wstring source_file;

	MatchResult(int _x = 0, int _y = 0, int _w = 0, int _h = 0, float _scale = 1.0f, const std::wstring& _source = L"")
		: x(_x), y(_y), w(_w), h(_h), scale(_scale), source_file(_source) {
	}
};

// ============================================================================
// HELPER: FormatMatchResults
// ============================================================================
// Description:
//   Formats match results into string format for return to caller.
//
// Parameters:
//   matches - Vector of match results
//   center_pos - Whether to return center position (1) or top-left (0)
//
// Returns:
//   Formatted string: {count}[x1|y1|w1|h1,x2|y2|w2|h2,...]
// ============================================================================
inline std::wstring FormatMatchResults(const std::vector<MatchResult>& matches, int center_pos) {
	std::wstringstream ss;
	
	if (matches.empty()) {
		ss << L"{0}[]";
	} else {
		ss << L"{" << matches.size() << L"}[";
		for (size_t i = 0; i < matches.size(); ++i) {
			if (i > 0) ss << L",";
			
			int x = matches[i].x;
			int y = matches[i].y;
			
			if (center_pos == 1) {
				x += matches[i].w / 2;
				y += matches[i].h / 2;
			}
			
			ss << x << L"|" << y << L"|" << matches[i].w << L"|" << matches[i].h;
		}
		ss << L"]";
	}
	
	return ss.str();
}

enum class SearchMode {
	ScreenSearch,
	SearchImageInImage,
	HBitmapSearch
};

// =================================================================================================
// SearchParams: Unified parameter structure for all image search operations
// =================================================================================================
// Cache System:
// - use_cache = 0: Disables caching completely (default for compatibility)
// - use_cache = 1: Enables in-memory + persistent disk cache for faster repeated searches
//   * Cache is validated on each lookup to ensure accuracy
//   * Invalid cache entries are automatically removed after 3 misses
//   * Cache persists across DLL reloads for better performance
// =================================================================================================
struct SearchParams {
	SearchMode mode = SearchMode::ScreenSearch;
	const wchar_t* image_files = nullptr;
	int left = 0, top = 0, right = 0, bottom = 0;
	int screen = 0;
	const wchar_t* source_image = nullptr;
	const wchar_t* target_images = nullptr;
	HBITMAP Source_hbitmap = nullptr;
	HBITMAP Target_hbitmap = nullptr;
	int tolerance = 10;
	int max_results = 1;
	int center_pos = 1;
	float min_scale = 1.0f;
	float max_scale = 1.0f;
	float scale_step = 0.1f;
	int return_debug = 0;
	int use_cache = 0;  // 0 = disabled, 1 = enabled
};

// ============================================================================
// HELPER: BuildDebugString
// ============================================================================
// Description:
//   Builds complete debug string with timing and parameters.
//   Reduces code duplication across all error handling paths.
//
// Parameters:
//   duration_ms - Execution time in milliseconds
//   params - Search parameters
//   extra_info - Optional extra information (e.g., "error=...", "buffer_size=...")
//
// Returns:
//   Complete debug string: "(time=123ms, params=..., extra_info)"
// ============================================================================
inline std::wstring BuildDebugString(long long duration_ms, const SearchParams& params, const std::wstring& extra_info = L"") {
	std::wstringstream ss;
	ss << L"(time=" << duration_ms << L"ms";
	
	if (!extra_info.empty()) {
		ss << L", " << extra_info;
	}
	
	ss << L", params=left:" << params.left << L",top:" << params.top 
	   << L",right:" << params.right << L",bottom:" << params.bottom
	   << L",screen:" << params.screen
	   << L",use_cache:" << params.use_cache
	   << L",tolerance:" << params.tolerance << L",max_results:" << params.max_results
	   << L",center_pos:" << params.center_pos << L",min_scale:" << FormatFloat(params.min_scale)
	   << L",max_scale:" << FormatFloat(params.max_scale) << L",scale_step:" << FormatFloat(params.scale_step)
	   << L",mode:" << static_cast<int>(params.mode) << L")";
	
	return ss.str();
}

struct CacheEntry {
	POINT position = { 0, 0 };
	int miss_count = 0;
	std::chrono::steady_clock::time_point last_used = std::chrono::steady_clock::now();
};

// ============================================================================
// CACHE SYSTEM - Global Variables
// ============================================================================
// Description:
//   Two-tier caching system for image search results:
//   1. In-memory LRU cache (fast, volatile)
//   2. Persistent disk cache (survives DLL reload, slower)
//
// Cache Key Format:
//   "normalized_path|tolerance|transparent|scale"
//   Example: "c:\images\icon.png|10|1|1.0"
//
// Cache Validation:
//   - Each cache entry tracks miss count
//   - After 3 consecutive misses, entry is invalidated and removed
//   - Prevents stale cache from causing false negatives
// ============================================================================
std::deque<std::pair<std::wstring, CacheEntry>> g_location_cache_lru;  // LRU queue: most recent first
std::unordered_map<std::wstring, size_t> g_location_cache_index;       // Fast lookup: key -> index in LRU
SharedMutex g_cache_mutex;                                             // Thread-safe access to cache (XP compatible)
std::wstring g_cache_base_dir;                                        // Base directory for disk cache files
HANDLE g_hCacheFileMutex = nullptr;                                   // System-wide mutex for file cache

// ============================================================================
// HELPER: _RebuildCacheIndex
// ============================================================================
// Description:
//   Rebuilds the hash map index after LRU queue modifications.
//   Called after insertions, deletions, or reordering of cache entries.
// ============================================================================
void _RebuildCacheIndex() {
	g_location_cache_index.clear();
	for (size_t i = 0; i < g_location_cache_lru.size(); ++i) {
		g_location_cache_index[g_location_cache_lru[i].first] = i;
	}
}

// ============================================================================
// HELPER: GetCacheBaseDir
// ============================================================================
// Description:
//   Returns the base directory for persistent disk cache files.
//   Uses system temp directory and creates it if needed.
// ============================================================================
std::wstring GetCacheBaseDir() {
	if (!g_cache_base_dir.empty()) return g_cache_base_dir;

	wchar_t temp_path[MAX_PATH];
	DWORD path_len = GetTempPathW(MAX_PATH, temp_path);
	if (path_len > 0 && path_len < MAX_PATH) {
		g_cache_base_dir = temp_path;
		try {
			FileSystem::create_directories(g_cache_base_dir);
		}
		catch (...) {}
		return g_cache_base_dir;
	}
	return L"";
}

// ============================================================================
// HELPER: GetNormalizedPathKey
// ============================================================================
// Description:
//   Normalizes file paths for consistent cache key generation.
//   Converts to canonical form and lowercase to handle path variations:
//   - "C:\Images\Icon.png" and "c:\images\icon.png" -> same key
//   - Relative vs absolute paths -> same key if same file
//   - Forward vs backslashes -> same key
//
// Returns:
//   Normalized lowercase canonical path, or lowercase original on error
// ============================================================================
std::wstring GetNormalizedPathKey(const std::wstring& path_str) {
	if (path_str.empty()) return L"";
	try {
		// Use FileSystem::canonical for XP compatibility
		std::wstring canonical_path = FileSystem::canonical(path_str);
		std::transform(canonical_path.begin(), canonical_path.end(), canonical_path.begin(),
			[](wchar_t c) { return std::towlower(c); });
		return canonical_path;
	}
	catch (...) {
		// Fallback: just lowercase the original path
		std::wstring lower_path = path_str;
		std::transform(lower_path.begin(), lower_path.end(), lower_path.begin(),
			[](wchar_t c) { return std::towlower(c); });
		return lower_path;
	}
}

// ============================================================================
// HELPER: GenerateCacheKey
// ============================================================================
// Description:
//   Generates a unique cache key from search parameters.
//   Two searches with identical parameters will produce identical keys,
//   ensuring cache hits for repeated searches.
//
// Format:
//   "normalized_primary_path|normalized_secondary_path|tolerance|transparent|scale"
//
// Example:
//   GenerateCacheKey("C:\screen.png", "icon.png", 10, true, 1.0)
//   -> "c:\screen.png|c:\icon.png|10|1|1.0"
// ============================================================================
std::wstring GenerateCacheKey(const std::wstring& primary_path, const std::wstring& secondary_path = L"",
	int tolerance = 0, bool transparent = false, float scale = 1.0f) {
	std::wstring normalized_primary = GetNormalizedPathKey(primary_path);
	std::wstringstream ss;
	
	// OPTIMIZATION: Pre-allocate capacity to reduce reallocations
	// Estimate: path length + secondary path + 50 chars for params
	size_t estimated_size = normalized_primary.length() + 50;
	if (!secondary_path.empty()) {
		estimated_size += secondary_path.length();
	}
	ss.str().reserve(estimated_size);
	
	ss << normalized_primary;
	if (!secondary_path.empty()) {
		std::wstring normalized_secondary = GetNormalizedPathKey(secondary_path);
		ss << L"|" << normalized_secondary;
	}
	ss << L"|" << tolerance << L"|" << transparent << L"|" << std::fixed << std::setprecision(1) << scale;
	return ss.str();
}

std::wstring GetCacheFileForImage(const std::wstring& cache_key) {
	std::size_t hasher = std::hash<std::wstring>{}(cache_key);
	std::wstringstream ss;
	ss << L"~CACHE_IMGSEARCH_V2_" << std::hex << std::uppercase << hasher << L".dat";
	std::wstring base_dir = GetCacheBaseDir();
	if (!base_dir.empty() && base_dir.back() != L'\\') base_dir += L'\\';
	return base_dir + ss.str();
}

void LoadCacheForImage(const std::wstring& cache_key) {
	if (cache_key.empty()) return;

	if (!g_hCacheFileMutex) return;

	ScopedMutex file_lock(g_hCacheFileMutex);
	if (!file_lock.IsLocked()) return;

	try {
		std::wstring cache_file_path = GetCacheFileForImage(cache_key);
		std::wifstream cache_file(cache_file_path);
		if (cache_file.is_open()) {
			std::wstring line;
			std::getline(cache_file, line);
			size_t pos = line.find(L'|');
			if (pos != std::wstring::npos) {
				std::wstring x_str = line.substr(0, pos);
				std::wstring y_str = line.substr(pos + 1);

				try {
					int x = std::stoi(x_str);
					int y = std::stoi(y_str);

					if (x >= -10000 && x <= 50000 && y >= -10000 && y <= 50000) {
						CacheEntry entry;
						entry.position = { x, y };
						entry.miss_count = 0;
						entry.last_used = std::chrono::steady_clock::now();

						std::unique_lock<SharedMutex> lock(g_cache_mutex);
						g_location_cache_lru.push_front({ cache_key, entry });

						while (g_location_cache_lru.size() > MAX_CACHED_LOCATIONS) {
							g_location_cache_lru.pop_back();
						}

						_RebuildCacheIndex();
					}
				}
				catch (const std::exception&) {
				}
			}
		}
	}
	catch (...) {
	}
}

void SaveCacheForImage(const std::wstring& cache_key, POINT pos) {
	if (cache_key.empty()) return;

	if (!g_hCacheFileMutex) return;

	ScopedMutex file_lock(g_hCacheFileMutex);
	if (!file_lock.IsLocked()) return;

	try {
		std::wstring cache_file_path = GetCacheFileForImage(cache_key);
		// Extract parent directory and create it
		std::wstring parent_dir = cache_file_path.substr(0, cache_file_path.find_last_of(L"\\"));
		FileSystem::create_directories(parent_dir);
		std::wofstream cache_file(cache_file_path, std::ios::trunc);
		if (cache_file.is_open()) {
			cache_file << pos.x << L"|" << pos.y;
		}
	}
	catch (...) {}
}

void RemoveFromCache(const std::wstring& cache_key) {
	if (cache_key.empty()) return;

	{
		std::unique_lock<SharedMutex> lock(g_cache_mutex);
		auto it = g_location_cache_index.find(cache_key);
		if (it != g_location_cache_index.end()) {
			size_t idx = it->second;
			if (idx < g_location_cache_lru.size()) {
				g_location_cache_lru.erase(g_location_cache_lru.begin() + idx);
				_RebuildCacheIndex();
			}
		}
	}

	try {
		std::wstring cache_file_path = GetCacheFileForImage(cache_key);
		FileSystem::remove(cache_file_path);
	}
	catch (...) {}
}

Optional<CacheEntry> GetCachedLocation(const std::wstring& cache_key) {
	std::unique_lock<SharedMutex> lock(g_cache_mutex);
	auto it = g_location_cache_index.find(cache_key);
	if (it != g_location_cache_index.end()) {
		size_t idx = it->second;

		if (idx >= g_location_cache_lru.size()) {
			_RebuildCacheIndex();
			it = g_location_cache_index.find(cache_key);
			if (it == g_location_cache_index.end()) return Optional<CacheEntry>();
			idx = it->second;
		}

		auto entry = g_location_cache_lru[idx].second;
		entry.last_used = std::chrono::steady_clock::now();

		if (idx > 0) {
			auto item = g_location_cache_lru[idx];
			g_location_cache_lru.erase(g_location_cache_lru.begin() + idx);
			g_location_cache_lru.push_front(item);
			_RebuildCacheIndex();
		}

		// Return by value to avoid Optional<CacheEntry&> reference issue
		return Optional<CacheEntry>(entry);
	}
	return Optional<CacheEntry>();
}

void UpdateCachedLocation(const std::wstring& cache_key, const CacheEntry& entry) {
	std::unique_lock<SharedMutex> lock(g_cache_mutex);

	auto it = g_location_cache_index.find(cache_key);
	if (it != g_location_cache_index.end()) {
		size_t idx = it->second;
		g_location_cache_lru[idx].second = entry;

		if (idx > 0) {
			auto item = g_location_cache_lru[idx];
			g_location_cache_lru.erase(g_location_cache_lru.begin() + idx);
			g_location_cache_lru.push_front(item);
			_RebuildCacheIndex();
		}
	}
	else {
		g_location_cache_lru.push_front({ cache_key, entry });

		while (g_location_cache_lru.size() > MAX_CACHED_LOCATIONS) {
			g_location_cache_lru.pop_back();
		}
		_RebuildCacheIndex();
	}
}

struct BitmapCacheEntry {
	std::shared_ptr<PixelBuffer> buffer;
	std::wstring key;
};

std::deque<BitmapCacheEntry> g_bitmap_cache;
std::mutex g_bitmap_cache_mutex;
std::unordered_map<std::wstring, size_t> g_bitmap_cache_index;

void _RebuildBitmapCacheIndex() {
	g_bitmap_cache_index.clear();
	for (size_t i = 0; i < g_bitmap_cache.size(); ++i) {
		g_bitmap_cache_index[g_bitmap_cache[i].key] = i;
	}
}

std::shared_ptr<PixelBuffer> GetCachedBitmap(const std::wstring& key) {
	std::lock_guard<std::mutex> lock(g_bitmap_cache_mutex);

	auto it = g_bitmap_cache_index.find(key);
	if (it != g_bitmap_cache_index.end()) {
		size_t idx = it->second;
		auto entry = g_bitmap_cache[idx];

		if (idx > 0) {
			g_bitmap_cache.erase(g_bitmap_cache.begin() + idx);
			g_bitmap_cache.push_front(entry);
			_RebuildBitmapCacheIndex();
		}
		return entry.buffer;
	}
	return nullptr;
}

void CacheBitmap(const std::wstring& key, std::shared_ptr<PixelBuffer> buffer) {
	std::lock_guard<std::mutex> lock(g_bitmap_cache_mutex);

	for (auto it = g_bitmap_cache.begin(); it != g_bitmap_cache.end(); ++it) {
		if (it->key == key) {
			g_bitmap_cache.erase(it);
			break;
		}
	}

	g_bitmap_cache.push_front({ buffer, key });

	while (g_bitmap_cache.size() > MAX_CACHED_BITMAPS) {
		g_bitmap_cache.pop_back();
	}
}

struct PixelBufferPool {
	std::vector<std::vector<COLORREF>> buffers;
	std::mutex mutex;
	std::unordered_map<size_t, std::vector<std::vector<COLORREF>>> size_buckets;

	std::vector<COLORREF> Acquire(size_t size) {
		std::lock_guard<std::mutex> lock(mutex);

		size_t bucket_size = (size + 1023) / 1024 * 1024;

		auto& bucket = size_buckets[bucket_size];
		if (!bucket.empty()) {
			auto buf = std::move(bucket.back());
			bucket.pop_back();
			buf.resize(size);
			return buf;
		}

		return std::vector<COLORREF>(size);
	}

	void Release(std::vector<COLORREF>&& buffer) {
		if (buffer.empty()) return;
		std::lock_guard<std::mutex> lock(mutex);
		
		// CRITICAL FIX: Count BEFORE adding to prevent memory leak
		// Previous bug: Counted after adding, causing gradual memory leak
		size_t buffer_capacity = buffer.capacity();
		size_t bucket_size = (buffer_capacity + 1023) / 1024 * 1024;
		
		// Count total buffers across all buckets BEFORE adding
		size_t total_buffers = 0;
		for (const auto& pair : size_buckets) {
			total_buffers += pair.second.size();
		}
		
		int max_size = g_pixel_pool_size.load(std::memory_order_relaxed);
		if (total_buffers < static_cast<size_t>(max_size)) {
			size_buckets[bucket_size].push_back(std::move(buffer));
		}
		// If pool is full, buffer will be destroyed by unique_ptr automatically
	}
};

PixelBufferPool g_pixel_pool;

// PixelBuffer special member implementations
PixelBuffer::~PixelBuffer() {
	if (owns_memory && !pixels.empty()) {
		g_pixel_pool.Release(std::move(pixels));
	}
}

PixelBuffer::PixelBuffer(PixelBuffer&& other) noexcept
	: pixels(std::move(other.pixels))
	, width(other.width)
	, height(other.height)
	, has_alpha(other.has_alpha)
	, owns_memory(other.owns_memory) {
	other.owns_memory = false;
}

PixelBuffer& PixelBuffer::operator=(PixelBuffer&& other) noexcept {
	if (this != &other) {
		if (owns_memory && !pixels.empty()) {
			g_pixel_pool.Release(std::move(pixels));
		}
		pixels = std::move(other.pixels);
		width = other.width;
		height = other.height;
		has_alpha = other.has_alpha;
		owns_memory = other.owns_memory;
		other.owns_memory = false;
	}
	return *this;
}

bool DetectAlphaChannel(const PixelBuffer& buffer) {
	size_t sample_size = std::min<size_t>(buffer.pixels.size(), 1000);
	size_t sample_step = std::max<size_t>(1, buffer.pixels.size() / sample_size);

	for (size_t i = 0; i < buffer.pixels.size(); i += sample_step) {
		uint8_t alpha = (buffer.pixels[i] >> 24) & 0xFF;
		if (alpha < 255) {
			return true;
		}
	}
	return false;
}

Optional<PixelBuffer> LoadImageFromFile_GDI(const std::wstring& file_path) {
	InitializeGdiplus();

	std::wstring cache_key = L"DECODE_" + GetNormalizedPathKey(file_path);
	auto cached = GetCachedBitmap(cache_key);
	if (cached) {
		PixelBuffer result;
		result.width = cached->width;
		result.height = cached->height;
		result.has_alpha = cached->has_alpha;
		result.pixels = cached->pixels;
		result.owns_memory = false;
		return result;
	}

	auto bitmap = std::make_unique<Bitmap>(file_path.c_str());
	if (!bitmap) {
		SetLastError(ERROR_FILE_NOT_FOUND);
		return Optional<PixelBuffer>();
	}

	Status status = bitmap->GetLastStatus();
	if (status != Ok) {
		SetLastError(ERROR_FILE_NOT_FOUND);
		return Optional<PixelBuffer>();
	}

	int width = bitmap->GetWidth();
	int height = bitmap->GetHeight();
	if (width <= 0 || height <= 0 || width > 32000 || height > 32000) {
		return Optional<PixelBuffer>();
	}

	PixelFormat format = bitmap->GetPixelFormat();
	bool hasAlpha = (format & PixelFormatAlpha) || (format == PixelFormat32bppARGB);

	BitmapData bitmapData;
	Rect rect(0, 0, width, height);

	if (bitmap->LockBits(&rect, ImageLockModeRead, PixelFormat32bppARGB, &bitmapData) != Ok) {
		return Optional<PixelBuffer>();
	}

	PixelBuffer buffer;
	buffer.width = width;
	buffer.height = height;
	buffer.pixels = g_pixel_pool.Acquire(width * height);
	if (buffer.pixels.capacity() < static_cast<size_t>(width * height)) {
		bitmap->UnlockBits(&bitmapData);
		return Optional<PixelBuffer>();
	}
	buffer.pixels.resize(width * height);

	BYTE* pixels = (BYTE*)bitmapData.Scan0;
	int stride = bitmapData.Stride;

	for (int y = 0; y < height; y++) {
		DWORD* row = (DWORD*)(pixels + y * stride);
		for (int x = 0; x < width; x++) {
			DWORD argb = row[x];
			BYTE a = (argb >> 24) & 0xFF;
			BYTE r = (argb >> 16) & 0xFF;
			BYTE g = (argb >> 8) & 0xFF;
			BYTE b = argb & 0xFF;
			
			// Use helper function to unpremultiply alpha
			buffer.pixels[y * width + x] = UnpremultiplyAlpha(r, g, b, a);
		}
	}

	bitmap->UnlockBits(&bitmapData);

	buffer.has_alpha = hasAlpha && DetectAlphaChannel(buffer);

	auto shared_buffer = std::make_shared<PixelBuffer>();
	shared_buffer->width = buffer.width;
	shared_buffer->height = buffer.height;
	shared_buffer->has_alpha = buffer.has_alpha;
	shared_buffer->pixels = buffer.pixels;
	shared_buffer->owns_memory = false;

	buffer.owns_memory = false;

	CacheBitmap(cache_key, shared_buffer);

	return buffer;
}

Optional<PixelBuffer> ScaleBitmap_GDI(const PixelBuffer& source, int newW, int newH) {
	if (!source.IsValid()) return Optional<PixelBuffer>();
	if (newW <= 0 || newH <= 0 || newW > 32000 || newH > 32000) return Optional<PixelBuffer>();

	size_t source_hash = 0;
	size_t sample_step = std::max<size_t>(1, source.pixels.size() / 100);
	for (size_t i = 0; i < source.pixels.size(); i += sample_step) {
		source_hash ^= std::hash<COLORREF>{}(source.pixels[i]) + 0x9e3779b9 + (source_hash << 6) + (source_hash >> 2);
	}

	std::wstringstream cache_key_ss;
	cache_key_ss << L"SCALED_" << std::hex << source_hash << L"_"
		<< std::dec << source.width << L"x" << source.height
		<< L"_to_" << newW << L"x" << newH;
	std::wstring cache_key = cache_key_ss.str();

	auto cached = GetCachedBitmap(cache_key);
	if (cached) {
		PixelBuffer result;
		result.width = cached->width;
		result.height = cached->height;
		result.has_alpha = cached->has_alpha;
		result.pixels = cached->pixels;
		result.owns_memory = false;
		return result;
	}

	InitializeGdiplus();

	Bitmap srcBitmap(source.width, source.height, PixelFormat32bppARGB);
	BitmapData srcData;
	Rect srcRect(0, 0, source.width, source.height);

	if (srcBitmap.LockBits(&srcRect, ImageLockModeWrite, PixelFormat32bppARGB, &srcData) != Ok) {
		return Optional<PixelBuffer>();
	}

	BYTE* srcPixels = (BYTE*)srcData.Scan0;
	int srcStride = srcData.Stride;

	for (int y = 0; y < source.height; y++) {
		DWORD* row = (DWORD*)(srcPixels + y * srcStride);
		for (int x = 0; x < source.width; x++) {
			COLORREF pixel = source.pixels[y * source.width + x];
			// Use helper function to premultiply alpha for GDI+
			row[x] = PremultiplyAlpha(pixel);
		}
	}

	srcBitmap.UnlockBits(&srcData);

	Bitmap dstBitmap(newW, newH, PixelFormat32bppARGB);
	Graphics graphics(&dstBitmap);
	graphics.SetInterpolationMode(InterpolationModeHighQualityBicubic);
	graphics.SetPixelOffsetMode(PixelOffsetModeHighQuality);
	graphics.SetSmoothingMode(SmoothingModeHighQuality);

	if (graphics.DrawImage(&srcBitmap, 0, 0, newW, newH) != Ok) {
		return Optional<PixelBuffer>();
	}

	BitmapData dstData;
	Rect dstRect(0, 0, newW, newH);

	if (dstBitmap.LockBits(&dstRect, ImageLockModeRead, PixelFormat32bppARGB, &dstData) != Ok) {
		return Optional<PixelBuffer>();
	}

	PixelBuffer result;
	result.width = newW;
	result.height = newH;
	result.has_alpha = source.has_alpha;
	result.pixels = g_pixel_pool.Acquire(newW * newH);
	if (result.pixels.capacity() < static_cast<size_t>(newW * newH)) {
		dstBitmap.UnlockBits(&dstData);
		return Optional<PixelBuffer>();
	}
	result.pixels.resize(newW * newH);

	BYTE* dstPixels = (BYTE*)dstData.Scan0;
	int dstStride = dstData.Stride;

	for (int y = 0; y < newH; y++) {
		DWORD* row = (DWORD*)(dstPixels + y * dstStride);
		for (int x = 0; x < newW; x++) {
			DWORD argb = row[x];
			BYTE a = (argb >> 24) & 0xFF;
			BYTE r = (argb >> 16) & 0xFF;
			BYTE g = (argb >> 8) & 0xFF;
			BYTE b = argb & 0xFF;
			
			// Use helper function to unpremultiply alpha
			result.pixels[y * newW + x] = UnpremultiplyAlpha(r, g, b, a);
		}
	}

	dstBitmap.UnlockBits(&dstData);

	auto shared_result = std::make_shared<PixelBuffer>();
	shared_result->width = result.width;
	shared_result->height = result.height;
	shared_result->has_alpha = result.has_alpha;
	shared_result->pixels = result.pixels;
	shared_result->owns_memory = false;

	result.owns_memory = false;

	CacheBitmap(cache_key, shared_result);

	return result;
}

Optional<PixelBuffer> GetBitmapPixels_GDI(HBITMAP hBitmap) {
	if (!hBitmap) return Optional<PixelBuffer>();

	InitializeGdiplus();

	BITMAP bm;
	if (!GetObject(hBitmap, sizeof(BITMAP), &bm)) return Optional<PixelBuffer>();

	int width = bm.bmWidth;
	int height = bm.bmHeight;
	if (width <= 0 || height <= 0 || width > 32000 || height > 32000) return Optional<PixelBuffer>();

	auto bitmap = std::unique_ptr<Bitmap>(Bitmap::FromHBITMAP(hBitmap, NULL));
	if (!bitmap || bitmap->GetLastStatus() != Ok) {
		return Optional<PixelBuffer>();
	}

	BitmapData bitmapData;
	Rect rect(0, 0, width, height);

	if (bitmap->LockBits(&rect, ImageLockModeRead, PixelFormat32bppARGB, &bitmapData) != Ok) {
		return Optional<PixelBuffer>();
	}

	PixelBuffer buffer;
	buffer.width = width;
	buffer.height = height;

	size_t pixel_count = static_cast<size_t>(width) * height;
	if (pixel_count > 100000000) {
		bitmap->UnlockBits(&bitmapData);
		return Optional<PixelBuffer>();
	}

	buffer.pixels = g_pixel_pool.Acquire(pixel_count);
	buffer.pixels.resize(pixel_count);

	BYTE* pixels = (BYTE*)bitmapData.Scan0;
	int stride = bitmapData.Stride;

	for (int y = 0; y < height; y++) {
		DWORD* row = (DWORD*)(pixels + y * stride);
		for (int x = 0; x < width; x++) {
			DWORD argb = row[x];
			BYTE a = (argb >> 24) & 0xFF;
			BYTE r = (argb >> 16) & 0xFF;
			BYTE g = (argb >> 8) & 0xFF;
			BYTE b = argb & 0xFF;
			
			// Use helper function to unpremultiply alpha
			buffer.pixels[y * width + x] = UnpremultiplyAlpha(r, g, b, a);
		}
	}

	bitmap->UnlockBits(&bitmapData);

	buffer.has_alpha = DetectAlphaChannel(buffer);

	return buffer;
}

struct MonitorInfo {
	RECT bounds;
	int index;
	bool isPrimary;
	
	MonitorInfo() : index(0), isPrimary(false) {
		bounds = {0, 0, 0, 0};
	}
};

std::vector<MonitorInfo> g_monitors;
std::mutex g_monitors_mutex;

BOOL CALLBACK MonitorEnumProc(HMONITOR hMonitor, HDC hdcMonitor, LPRECT lprcMonitor, LPARAM dwData) {
	auto* monitors = reinterpret_cast<std::vector<MonitorInfo>*>(dwData);
	MonitorInfo info;
	info.bounds = *lprcMonitor;
	info.index = static_cast<int>(monitors->size());
	
	// Check if this is the primary monitor
	MONITORINFO mi;
	mi.cbSize = sizeof(MONITORINFO);
	if (GetMonitorInfo(hMonitor, &mi)) {
		info.isPrimary = (mi.dwFlags & MONITORINFOF_PRIMARY) != 0;
	}
	
	monitors->push_back(info);
	return TRUE;
}

// CRITICAL FIX: Previous version had race condition - callback could run while lock held
// New version: Collect to temp vector first, then swap under lock
void EnumerateMonitors() {
	// Enumerate into temporary vector (no lock needed, no race condition)
	std::vector<MonitorInfo> temp_monitors;
	EnumDisplayMonitors(NULL, NULL, MonitorEnumProc, reinterpret_cast<LPARAM>(&temp_monitors));
	
	// Swap with global vector under lock (fast, no race condition)
	{
		std::lock_guard<std::mutex> lock(g_monitors_mutex);
		g_monitors.swap(temp_monitors);
	}
	// temp_monitors destructor automatically cleans up old data
}

bool GetMonitorBounds(int screen_index, RECT& bounds) {
	// CRITICAL FIX: Same race condition as EnumerateMonitors!
	// Enumerate to temp vector first, then swap under lock
	std::vector<MonitorInfo> temp_monitors;
	EnumDisplayMonitors(NULL, NULL, MonitorEnumProc, reinterpret_cast<LPARAM>(&temp_monitors));
	
	// Validate screen_index range BEFORE locking
	if (screen_index <= 0 || screen_index > static_cast<int>(temp_monitors.size()) || temp_monitors.empty()) {
		return false;
	}
	
	// Update global monitors under lock (fast swap)
	{
		std::lock_guard<std::mutex> lock(g_monitors_mutex);
		g_monitors.swap(temp_monitors);
	}
	
	// Return bounds from temp (safe - no longer shared)
	bounds = temp_monitors[screen_index - 1].bounds;
	return true;
}

// ============================================================================
// HELPER: GetScreenBounds
// ============================================================================
// Description:
//   Gets screen bounds based on monitor selection mode.
//   Centralizes screen bounds logic used across multiple functions.
//
// Parameters:
//   iScreen - Monitor selection (0=primary, >0=specific monitor, <0=virtual)
//   left, top, width, height - Output parameters for screen bounds
// ============================================================================
static void GetScreenBounds(int iScreen, int& left, int& top, int& width, int& height) {
	if (iScreen > 0) {
		RECT monitorBounds;
		if (GetMonitorBounds(iScreen, monitorBounds)) {
			left = monitorBounds.left;
			top = monitorBounds.top;
			width = monitorBounds.right - monitorBounds.left;
			height = monitorBounds.bottom - monitorBounds.top;
			return;
		}
		else {
			left = 0; top = 0;
			width = GetSystemMetrics(SM_CXSCREEN);
			height = GetSystemMetrics(SM_CYSCREEN);
		}
	}
	else if (iScreen == 0) {
		// iScreen = 0: User-specified region only (use primary screen dimensions as max bounds)
		left = 0;
		top = 0;
		width = GetSystemMetrics(SM_CXSCREEN);
		height = GetSystemMetrics(SM_CYSCREEN);
	}
	else { // iScreen < 0
		left = GetSystemMetrics(SM_XVIRTUALSCREEN);
		top = GetSystemMetrics(SM_YVIRTUALSCREEN);
		width = GetSystemMetrics(SM_CXVIRTUALSCREEN);
		height = GetSystemMetrics(SM_CYVIRTUALSCREEN);
	}
}

// ============================================================================
// HELPER: NormalizeCoordinates
// ============================================================================
// Description:
//   Normalizes and validates capture coordinates based on screen mode.
//   Reduces code duplication in coordinate handling logic.
//
// Parameters:
//   iLeft, iTop, iRight, iBottom - Input coordinates
//   iScreen - Screen mode (0=primary, >0=monitor, <0=virtual)
//   outLeft, outTop, outRight, outBottom - Normalized output coordinates
//
// Returns:
//   true if coordinates are valid, false otherwise
// ============================================================================
static bool NormalizeCoordinates(int iLeft, int iTop, int iRight, int iBottom, int iScreen,
                                  int& outLeft, int& outTop, int& outRight, int& outBottom) {
	int screenLeft, screenTop, screenWidth, screenHeight;
	GetScreenBounds(iScreen, screenLeft, screenTop, screenWidth, screenHeight);
	
	int screenRight = screenLeft + screenWidth;
	int screenBottom = screenTop + screenHeight;
	
	// Handle different screen modes
	if (iScreen > 0) {
		// Specific monitor: Handle (0,0,0,0) as full monitor capture
		if (iLeft == 0 && iTop == 0 && iRight == 0 && iBottom == 0) {
			outLeft = screenLeft;
			outTop = screenTop;
			outRight = screenRight;
			outBottom = screenBottom;
		}
		else {
				// User-specified region on specific monitor
			// Convert monitor-relative coords to absolute, then clamp
			int absLeft = screenLeft + iLeft;
			int absTop = screenTop + iTop;
			int absRight = (iRight == -1 || iRight == 0) ? screenRight : (screenLeft + iRight);
			int absBottom = (iBottom == -1 || iBottom == 0) ? screenBottom : (screenTop + iBottom);
			
			outLeft = clamp_value(absLeft, screenLeft, screenRight - 1);
			outTop = clamp_value(absTop, screenTop, screenBottom - 1);
			outRight = clamp_value(absRight, outLeft + 1, screenRight);
			outBottom = clamp_value(absBottom, outTop + 1, screenBottom);
		}
	}
	else if (iScreen == 0) {
		// iScreen=0: User provides exact coordinates (no clamping to allow multi-monitor)
		if (iLeft == 0 && iTop == 0 && iRight == 0 && iBottom == 0) {
			outLeft = 0;
			outTop = 0;
			outRight = screenWidth;
			outBottom = screenHeight;
		}
		else {
			outLeft = iLeft;
			outTop = iTop;
			outRight = (iRight == 0 || iRight == -1) ? screenWidth : iRight;
			outBottom = (iBottom == 0 || iBottom == -1) ? screenHeight : iBottom;
		}
	}
	else { // iScreen < 0 (Virtual screen)
		if (iLeft == 0 && iTop == 0 && iRight == 0 && iBottom == 0) {
			outLeft = screenLeft;
			outTop = screenTop;
			outRight = screenRight;
			outBottom = screenBottom;
		}
		else {
			if (iRight == -1 || iRight == 0) iRight = screenRight;
			if (iBottom == -1 || iBottom == 0) iBottom = screenBottom;
			
			outLeft = clamp_value(iLeft, screenLeft, screenRight - 1);
			outTop = clamp_value(iTop, screenTop, screenBottom - 1);
			outRight = clamp_value(iRight, outLeft + 1, screenRight);
			outBottom = clamp_value(iBottom, outTop + 1, screenBottom);
		}
	}
	
	// Validate final coordinates
	return (outLeft < outRight && outTop < outBottom);
}

// Internal unified screen capture function
static HBITMAP CaptureScreenInternal(int iLeft, int iTop, int iRight, int iBottom, int iScreen) {
    // NOTE: ScopedDpiAwareness is also set in UnifiedImageSearch for consistency
    // This ensures capture works correctly when called directly via Capture_Screen export
    ScopedDpiAwareness dpiScope;
	
	// Use helper function to normalize coordinates
	int left, top, right, bottom;
	if (!NormalizeCoordinates(iLeft, iTop, iRight, iBottom, iScreen, left, top, right, bottom)) {
		return nullptr; // Invalid coordinates
	}
	
	int width = right - left;
	int height = bottom - top;

	if (width <= 0 || height <= 0 || width > 32000 || height > 32000) return nullptr;

	HDC hdcScreen = GetDC(nullptr);
	if (!hdcScreen) return nullptr;

	HDC hdcMem = CreateCompatibleDC(hdcScreen);
	if (!hdcMem) {
		ReleaseDC(nullptr, hdcScreen);
		return nullptr;
	}

	HBITMAP hBitmap = CreateCompatibleBitmap(hdcScreen, width, height);
	if (!hBitmap) {
		DeleteDC(hdcMem);
		ReleaseDC(nullptr, hdcScreen);
		return nullptr;
	}

	HBITMAP hOldBitmap = (HBITMAP)SelectObject(hdcMem, hBitmap);
	BOOL success = BitBlt(hdcMem, 0, 0, width, height, hdcScreen, left, top, SRCCOPY);

	SelectObject(hdcMem, hOldBitmap);
	DeleteDC(hdcMem);
	ReleaseDC(nullptr, hdcScreen);

	if (!success) {
		DeleteObject(hBitmap);
		return nullptr;
	}

	return hBitmap;
}

Optional<PixelBuffer> CaptureScreen_GDI(int iLeft, int iTop, int iRight, int iBottom, int iScreen = 0) {
	HBITMAP hBitmap = CaptureScreenInternal(iLeft, iTop, iRight, iBottom, iScreen);
	if (!hBitmap) return Optional<PixelBuffer>();

	auto result = GetBitmapPixels_GDI(hBitmap);
	DeleteObject(hBitmap);

	return result;
}

namespace PixelComparison {
	// Helper: Check if search region is valid
	inline bool IsValidSearchRegion(int start_x, int start_y, int source_width, int source_height,
		int screen_width, int screen_height) noexcept {
		return start_x >= 0 && start_y >= 0 &&
			start_x + source_width <= screen_width &&
			start_y + source_height <= screen_height;
	}

	inline bool CheckApproxMatch_Scalar(
		const PixelBuffer& screen, const PixelBuffer& source,
		int start_x, int start_y, bool transparent_enabled, int tolerance) noexcept {

		if (!IsValidSearchRegion(start_x, start_y, source.width, source.height, screen.width, screen.height)) {
			return false;
		}

		int alpha_threshold = ComputeAlphaThreshold(transparent_enabled, tolerance);

		for (int y = 0; y < source.height; ++y) {
			const COLORREF* source_row = &source.pixels[y * source.width];
			const COLORREF* screen_row = &screen.pixels[(start_y + y) * screen.width + start_x];

			for (int x = 0; x < source.width; ++x) {
				COLORREF source_pixel = source_row[x];

				if (transparent_enabled) {
					uint8_t alpha = (source_pixel >> 24) & 0xFF;
					if (alpha < alpha_threshold) continue;
				}

				COLORREF screen_pixel = screen_row[x];
				if (std::abs((int)GetRValue(source_pixel) - (int)GetRValue(screen_pixel)) > tolerance ||
					std::abs((int)GetGValue(source_pixel) - (int)GetGValue(screen_pixel)) > tolerance ||
					std::abs((int)GetBValue(source_pixel) - (int)GetBValue(screen_pixel)) > tolerance) {
					return false;
				}
			}
		}
		return true;
	}

#ifdef _WIN64
	inline bool CheckApproxMatch_AVX2(
		const PixelBuffer& screen, const PixelBuffer& source,
		int start_x, int start_y, bool transparent_enabled, int tolerance) noexcept {

		if (!IsValidSearchRegion(start_x, start_y, source.width, source.height, screen.width, screen.height)) {
			return false;
		}

		int alpha_threshold = ComputeAlphaThreshold(transparent_enabled, tolerance);

		const __m256i v_alpha_threshold = _mm256_set1_epi32(alpha_threshold);
		const __m256i v_rgb_mask = _mm256_set1_epi32(0x00FFFFFF);
		const __m256i v_tolerance8 = _mm256_set1_epi8(static_cast<char>(tolerance));

		for (int y = 0; y < source.height; ++y) {
			const COLORREF* source_row = &source.pixels[y * source.width];
			const COLORREF* screen_row = &screen.pixels[(start_y + y) * screen.width + start_x];

			int x = 0;
			for (; x + 7 < source.width; x += 8) {
				__m256i v_source = _mm256_loadu_si256(reinterpret_cast<const __m256i*>(source_row + x));

				__m256i v_transparent_mask = _mm256_setzero_si256();
				if (transparent_enabled) {
					__m256i v_alpha = _mm256_srli_epi32(v_source, 24);
					__m256i v_is_transparent = _mm256_cmpgt_epi32(v_alpha_threshold, v_alpha);
					v_transparent_mask = v_is_transparent;
				}

				if (transparent_enabled && _mm256_testc_si256(v_transparent_mask, _mm256_set1_epi32(-1))) {
					continue;
				}

				__m256i v_screen = _mm256_loadu_si256(reinterpret_cast<const __m256i*>(screen_row + x));

				__m256i v_source_rgb = _mm256_and_si256(v_source, v_rgb_mask);
				__m256i v_screen_rgb = _mm256_and_si256(v_screen, v_rgb_mask);

				__m256i v_diff1 = _mm256_subs_epu8(v_source_rgb, v_screen_rgb);
				__m256i v_diff2 = _mm256_subs_epu8(v_screen_rgb, v_source_rgb);
				__m256i v_abs_diff = _mm256_or_si256(v_diff1, v_diff2);

				__m256i v_check = _mm256_subs_epu8(v_abs_diff, v_tolerance8);

				__m256i v_mismatch = _mm256_andnot_si256(v_transparent_mask, v_check);

				if (!_mm256_testz_si256(v_mismatch, v_mismatch)) {
					return false;
				}
			}

			for (; x < source.width; ++x) {
				COLORREF source_pixel = source_row[x];

				if (transparent_enabled) {
					uint8_t alpha = (source_pixel >> 24) & 0xFF;
					if (alpha < alpha_threshold) continue;
				}

				COLORREF screen_pixel = screen_row[x];
				if (std::abs((int)GetRValue(source_pixel) - (int)GetRValue(screen_pixel)) > tolerance ||
					std::abs((int)GetGValue(source_pixel) - (int)GetGValue(screen_pixel)) > tolerance ||
					std::abs((int)GetBValue(source_pixel) - (int)GetBValue(screen_pixel)) > tolerance) {
					return false;
				}
			}
		}
		return true;
	}

	inline bool CheckApproxMatch_AVX512(
		const PixelBuffer& screen, const PixelBuffer& source,
		int start_x, int start_y, bool transparent_enabled, int tolerance) noexcept {

		if (!IsValidSearchRegion(start_x, start_y, source.width, source.height, screen.width, screen.height)) {
			return false;
		}

		int alpha_threshold = ComputeAlphaThreshold(transparent_enabled, tolerance);

		const __m512i v_alpha_threshold = _mm512_set1_epi32(alpha_threshold << 24);
		const __m512i v_rgb_mask = _mm512_set1_epi32(0x00FFFFFF);
		const __m512i v_tolerance8 = _mm512_set1_epi8(static_cast<char>(tolerance));

		for (int y = 0; y < source.height; ++y) {
			const COLORREF* source_row = &source.pixels[y * source.width];
			const COLORREF* screen_row = &screen.pixels[(start_y + y) * screen.width + start_x];

			int x = 0;
			for (; x + 15 < source.width; x += 16) {
				__m512i v_source = _mm512_loadu_si512(reinterpret_cast<const __m512i*>(source_row + x));

				__mmask16 transparent_mask = 0;
				if (transparent_enabled) {
					__m512i v_alpha = _mm512_srli_epi32(v_source, 24);
					transparent_mask = _mm512_cmp_epi32_mask(v_alpha, _mm512_set1_epi32(alpha_threshold), _MM_CMPINT_LT);
				}

				if (transparent_enabled && transparent_mask == 0xFFFF) {
					continue;
				}

				__m512i v_screen = _mm512_loadu_si512(reinterpret_cast<const __m512i*>(screen_row + x));

				__m512i v_source_rgb = _mm512_and_si512(v_source, v_rgb_mask);
				__m512i v_screen_rgb = _mm512_and_si512(v_screen, v_rgb_mask);

				__m512i v_diff1 = _mm512_subs_epu8(v_source_rgb, v_screen_rgb);
				__m512i v_diff2 = _mm512_subs_epu8(v_screen_rgb, v_source_rgb);
				__m512i v_abs_diff = _mm512_or_si512(v_diff1, v_diff2);

				__mmask64 v_exceed = _mm512_cmp_epu8_mask(v_abs_diff, v_tolerance8, _MM_CMPINT_GT);

				__mmask64 transparent_byte_mask = 0;
				if (transparent_enabled && transparent_mask != 0) {
					uint64_t expanded = 0;
					for (int p = 0; p < 16; ++p) {
						if (transparent_mask & (1 << p)) {
							expanded |= (0xFULL << (p * 4));
						}
					}
					transparent_byte_mask = expanded;
				}

				__mmask64 v_mismatch = v_exceed & ~transparent_byte_mask;

				if (v_mismatch != 0) {
					return false;
				}
			}

			if (g_is_avx2_supported.load(std::memory_order_relaxed)) {
				for (; x + 7 < source.width; x += 8) {
					__m256i v_source = _mm256_loadu_si256(reinterpret_cast<const __m256i*>(source_row + x));
					__m256i v_transparent_mask = _mm256_setzero_si256();

					if (transparent_enabled) {
						__m256i v_alpha = _mm256_and_si256(v_source, _mm256_set1_epi32(0xFF000000));
						__m256i v_is_transparent = _mm256_cmpgt_epi32(_mm256_set1_epi32(alpha_threshold << 24), v_alpha);
						v_transparent_mask = v_is_transparent;
					}

					if (transparent_enabled && _mm256_testc_si256(v_transparent_mask, _mm256_set1_epi32(-1))) {
						continue;
					}

					__m256i v_screen = _mm256_loadu_si256(reinterpret_cast<const __m256i*>(screen_row + x));
					__m256i v_source_rgb = _mm256_and_si256(v_source, _mm256_set1_epi32(0x00FFFFFF));
					__m256i v_screen_rgb = _mm256_and_si256(v_screen, _mm256_set1_epi32(0x00FFFFFF));

					__m256i v_diff1 = _mm256_subs_epu8(v_source_rgb, v_screen_rgb);
					__m256i v_diff2 = _mm256_subs_epu8(v_screen_rgb, v_source_rgb);
					__m256i v_abs_diff = _mm256_or_si256(v_diff1, v_diff2);

					__m256i v_check = _mm256_subs_epu8(v_abs_diff, _mm256_set1_epi8(static_cast<char>(tolerance)));
					__m256i v_mismatch = _mm256_andnot_si256(v_transparent_mask, v_check);

					if (!_mm256_testz_si256(v_mismatch, v_mismatch)) {
						return false;
					}
				}
			}

			for (; x < source.width; ++x) {
				COLORREF source_pixel = source_row[x];

				if (transparent_enabled) {
					uint8_t alpha = (source_pixel >> 24) & 0xFF;
					if (alpha < alpha_threshold) continue;
				}

				COLORREF screen_pixel = screen_row[x];
				if (std::abs((int)GetRValue(source_pixel) - (int)GetRValue(screen_pixel)) > tolerance ||
					std::abs((int)GetGValue(source_pixel) - (int)GetGValue(screen_pixel)) > tolerance ||
					std::abs((int)GetBValue(source_pixel) - (int)GetBValue(screen_pixel)) > tolerance) {
					return false;
				}
			}
		}
		return true;
	}
#else
	inline bool CheckApproxMatch_SSE2(
		const PixelBuffer& screen, const PixelBuffer& source,
		int start_x, int start_y, bool transparent_enabled, int tolerance) noexcept {

		if (!IsValidSearchRegion(start_x, start_y, source.width, source.height, screen.width, screen.height)) {
			return false;
		}

		int alpha_threshold = ComputeAlphaThreshold(transparent_enabled, tolerance);

		const __m128i v_alpha_threshold = _mm_set1_epi32(alpha_threshold << 24);
		const __m128i v_rgb_mask = _mm_set1_epi32(0x00FFFFFF);
		const __m128i v_tolerance = _mm_set1_epi16(tolerance);
		const __m128i v_zero = _mm_setzero_si128();

		for (int y = 0; y < source.height; ++y) {
			const COLORREF* source_row = &source.pixels[y * source.width];
			const COLORREF* screen_row = &screen.pixels[(start_y + y) * screen.width + start_x];

			int x = 0;
			for (; x + 3 < source.width; x += 4) {
				__m128i v_source = _mm_loadu_si128(reinterpret_cast<const __m128i*>(source_row + x));

				__m128i v_transparent_mask = _mm_setzero_si128();
				if (transparent_enabled) {
					__m128i v_alpha = _mm_srli_epi32(v_source, 24);
					__m128i v_alpha_compare = _mm_cmplt_epi32(v_alpha, _mm_set1_epi32(alpha_threshold));
					v_transparent_mask = v_alpha_compare;
				}

				int mask = _mm_movemask_epi8(v_transparent_mask);
				if (transparent_enabled && mask == 0xFFFF) {
					continue;
				}

				__m128i v_screen = _mm_loadu_si128(reinterpret_cast<const __m128i*>(screen_row + x));

				__m128i v_source_rgb = _mm_and_si128(v_source, v_rgb_mask);
				__m128i v_screen_rgb = _mm_and_si128(v_screen, v_rgb_mask);

				__m128i v_source_lo = _mm_unpacklo_epi8(v_source_rgb, v_zero);
				__m128i v_source_hi = _mm_unpackhi_epi8(v_source_rgb, v_zero);
				__m128i v_screen_lo = _mm_unpacklo_epi8(v_screen_rgb, v_zero);
				__m128i v_screen_hi = _mm_unpackhi_epi8(v_screen_rgb, v_zero);

				__m128i v_diff_lo = _mm_sub_epi16(v_source_lo, v_screen_lo);
				__m128i v_diff_hi = _mm_sub_epi16(v_source_hi, v_screen_hi);

				__m128i v_abs_diff_lo = _mm_max_epi16(v_diff_lo, _mm_sub_epi16(v_zero, v_diff_lo));
				__m128i v_abs_diff_hi = _mm_max_epi16(v_diff_hi, _mm_sub_epi16(v_zero, v_diff_hi));

				__m128i v_check_lo = _mm_cmpgt_epi16(v_abs_diff_lo, v_tolerance);
				__m128i v_check_hi = _mm_cmpgt_epi16(v_abs_diff_hi, v_tolerance);

				__m128i v_check = _mm_packs_epi16(v_check_lo, v_check_hi);
				__m128i v_mismatch = _mm_andnot_si128(v_transparent_mask, v_check);

				if (_mm_movemask_epi8(v_mismatch) != 0) {
					return false;
				}
			}

			for (; x < source.width; ++x) {
				COLORREF source_pixel = source_row[x];

				if (transparent_enabled) {
					uint8_t alpha = (source_pixel >> 24) & 0xFF;
					if (alpha < alpha_threshold) continue;
				}

				COLORREF screen_pixel = screen_row[x];
				if (std::abs((int)GetRValue(source_pixel) - (int)GetRValue(screen_pixel)) > tolerance ||
					std::abs((int)GetGValue(source_pixel) - (int)GetGValue(screen_pixel)) > tolerance ||
					std::abs((int)GetBValue(source_pixel) - (int)GetBValue(screen_pixel)) > tolerance) {
					return false;
				}
			}
		}
		return true;
	}
#endif
}

// ============================================================================
// HELPER FUNCTION: CompareMatchResults
// ============================================================================
// Description:
//   Comparison function for sorting match results in top-to-bottom, left-to-right order.
//   Used by std::sort to organize multiple matches into a consistent order.
// ============================================================================
bool CompareMatchResults(const MatchResult& a, const MatchResult& b) {
	if (a.y != b.y) return a.y < b.y;  // Sort by Y first (top to bottom)
	return a.x < b.x;                  // Then by X (left to right)
}

// ============================================================================
// CORE ALGORITHM: SearchForBitmap
// ============================================================================
// Description:
//   Main image searching algorithm. Performs pixel-by-pixel comparison with
//   SIMD optimization (AVX512/AVX2/SSE2) and optional multi-threading.
//
// Algorithm:
//   1. Detect CPU capabilities and select fastest SIMD backend
//   2. For large images (>500px height) and find_all mode, use multi-threading
//   3. Scan source image row-by-row, column-by-column
//   4. For each position, call SIMD-optimized pixel comparison
//   5. Collect all matches or stop at first match based on find_all flag
//
// Performance Optimizations:
//   - SIMD instructions process 8-16 pixels simultaneously
//   - Multi-threading divides work across CPU cores
//   - Early-exit on first match when find_all=false
//   - Cache-friendly row-wise scanning
//
// Parameters:
//   Source           - Screen/source image to search within
//   Target           - Template image to find
//   search_left/top  - Offset to add to result coordinates
//   tolerance        - Color matching tolerance (0-255)
//   transparent_enabled - Skip pixels with low alpha channel
//   find_all         - Find all matches (true) or first only (false)
//   scale_factor     - Scale factor of current search (for reporting)
//   source_file      - Image filename (for debugging)
//   backend_used     - Output: SIMD backend actually used
//
// Returns:
//   Vector of MatchResult containing all found positions
// ============================================================================
std::vector<MatchResult> SearchForBitmap(
	const PixelBuffer& Source, const PixelBuffer& Target,
	int search_left, int search_top, int tolerance, bool transparent_enabled,
	bool find_all, float scale_factor, const std::wstring& source_file,
	std::wstring& backend_used) {

	std::vector<MatchResult> matches;
	if (Target.width > Source.width || Target.height > Source.height) return matches;

	backend_used = L"Scalar";

	auto CheckMatch = [&](int x, int y) -> bool {
#ifdef _WIN64
		if (g_is_avx512_supported.load(std::memory_order_relaxed)) {
			return PixelComparison::CheckApproxMatch_AVX512(Source, Target, x, y, transparent_enabled, tolerance);
		}
		else if (g_is_avx2_supported.load(std::memory_order_relaxed)) {
			return PixelComparison::CheckApproxMatch_AVX2(Source, Target, x, y, transparent_enabled, tolerance);
		}
		else {
			return PixelComparison::CheckApproxMatch_Scalar(Source, Target, x, y, transparent_enabled, tolerance);
		}
#else
		if (g_is_sse2_supported.load(std::memory_order_relaxed)) {
			return PixelComparison::CheckApproxMatch_SSE2(Source, Target, x, y, transparent_enabled, tolerance);
		}
		else {
			return PixelComparison::CheckApproxMatch_Scalar(Source, Target, x, y, transparent_enabled, tolerance);
		}
#endif
		};

#ifdef _WIN64
	if (g_is_avx512_supported.load(std::memory_order_relaxed)) {
		backend_used = L"AVX512";
	}
	else if (g_is_avx2_supported.load(std::memory_order_relaxed)) {
		backend_used = L"AVX2";
	}
	else {
		backend_used = L"Scalar";
	}
#else
	if (g_is_sse2_supported.load(std::memory_order_relaxed)) {
		backend_used = L"SSE2";
	}
	else {
		backend_used = L"Scalar";
	}
#endif

	// ========================================================================
	// MULTI-THREADING OPTIMIZATION
	// ========================================================================
	// For large images (>500px height) and find_all mode, split work across
	// CPU cores for maximum performance. Each thread searches a vertical slice.
	// ========================================================================
	if (find_all && Source.height > 500) {
		unsigned int num_threads = std::max(1u, std::thread::hardware_concurrency());
		int chunk_height = (Source.height - Target.height + 1) / num_threads;

		// Don't use threading if chunks would be too small (overhead > benefit)
		if (chunk_height < 50) {
			num_threads = 1;
		}

		if (num_threads > 1) {
			// Launch async tasks, each searching a vertical slice
			std::vector<std::future<std::vector<MatchResult>>> futures;

			for (unsigned int t = 0; t < num_threads; ++t) {
				int start_y = t * chunk_height;
				int end_y = (t == num_threads - 1) ? (Source.height - Target.height + 1) : ((t + 1) * chunk_height);

				futures.push_back(std::async(std::launch::async, [&, start_y, end_y]() {
					std::vector<MatchResult> local_matches;

					for (int y = start_y; y < end_y; ++y) {
						for (int x = 0; x <= Source.width - Target.width; ++x) {
							if (CheckMatch(x, y)) {
								local_matches.push_back(MatchResult(x + search_left, y + search_top,
									Target.width, Target.height, scale_factor, source_file));
							}
						}
					}

					return local_matches;
					}));
			}

			for (auto& fut : futures) {
				try {
					fut.wait();
					auto local_results = fut.get();
					matches.insert(matches.end(), local_results.begin(), local_results.end());
				}
				catch (const std::exception&) {
				}
			}

			std::sort(matches.begin(), matches.end(), CompareMatchResults);
			return matches;
		}
	}

	for (int y = 0; y <= Source.height - Target.height; ++y) {
		for (int x = 0; x <= Source.width - Target.width; ++x) {
			bool found = CheckMatch(x, y);
			if (found) {
				matches.push_back(MatchResult(x + search_left, y + search_top, Target.width, Target.height, scale_factor, source_file));
				if (!find_all) {
					return matches;
				}
			}
		}
	}

	return matches;
}

std::wstring UnifiedImageSearch(const SearchParams& params) {
	auto start_time = std::chrono::high_resolution_clock::now();

	// CRITICAL FIX: Set DPI awareness BEFORE GetScreenBounds/GetSystemMetrics
	// Otherwise GetSystemMetrics returns LOGICAL size instead of PHYSICAL size on scaled displays
	ScopedDpiAwareness dpiScope;

	std::call_once(g_feature_detection_flag, DetectFeatures);
	InitializeGdiplus();

	std::wstringstream result_stream;

	int tolerance = clamp_value(params.tolerance, 0, 255);
	float min_scale = clamp_value(params.min_scale, 0.1f, 5.0f);
	float max_scale = clamp_value(params.max_scale, min_scale, 5.0f);
	float scale_step = clamp_value(params.scale_step, 0.01f, 1.0f);
	scale_step = std::round(scale_step * 10.0f) / 10.0f;

	Optional<PixelBuffer> Source_opt;
	std::wstring Source_source;
	int search_offset_x = 0, search_offset_y = 0;

	int capture_left = 0, capture_top = 0, capture_right = 0, capture_bottom = 0;
	int capture_width = 0, capture_height = 0;

	if (params.mode == SearchMode::ScreenSearch) {
		int screenLeft, screenTop, screenWidth, screenHeight;
		GetScreenBounds(params.screen, screenLeft, screenTop, screenWidth, screenHeight);

		int screenRight = screenLeft + screenWidth;
		int screenBottom = screenTop + screenHeight;

		int left, top, right, bottom;

		if (params.screen == 0) {
			// iScreen == 0: Use exact user coordinates (supports multi-monitor with negative coords)
			if (params.left == 0 && params.top == 0 && params.right == 0 && params.bottom == 0) {
				// Special case: (0,0,0,0) = full primary screen
				left = 0;
				top = 0;
				right = screenWidth;
				bottom = screenHeight;
			}
			else {
				// Use coordinates as-is
				left = params.left;
				top = params.top;
				right = (params.right == 0 || params.right == -1) ? screenWidth : params.right;
				bottom = (params.bottom == 0 || params.bottom == -1) ? screenHeight : params.bottom;
			}
		}
		else if (params.left == 0 && params.top == 0 && params.right == 0 && params.bottom == 0) {
			// iScreen > 0 or < 0: (0,0,0,0) = full monitor or virtual screen
			left = screenLeft;
			top = screenTop;
			right = screenRight;
			bottom = screenBottom;
		}
		else {
			// iScreen > 0 or < 0: Clamp to specific monitor or virtual screen bounds
			left = clamp_value(params.left, screenLeft, screenRight - 1);
			top = clamp_value(params.top, screenTop, screenBottom - 1);
			right = (params.right <= left || params.right > screenRight) ? screenRight : params.right;
			bottom = (params.bottom <= top || params.bottom > screenBottom) ? screenBottom : params.bottom;
		}

		capture_left = left;
		capture_top = top;
		capture_right = right;
		capture_bottom = bottom;
		capture_width = capture_right - capture_left;
		capture_height = capture_bottom - capture_top;

		if (left >= right || top >= bottom) {
			auto end_time = std::chrono::high_resolution_clock::now();
			auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(end_time - start_time).count();
			result_stream << FormatError(ErrorCode::InvalidSearchRegion);

			if (params.return_debug > 0) {
				std::wstring extra = L"left:" + std::to_wstring(left) + L",top:" + std::to_wstring(top) 
					+ L",right:" + std::to_wstring(right) + L",bottom:" + std::to_wstring(bottom);
				result_stream << BuildDebugString(duration, params, extra);
			}
			return result_stream.str();
		}

		Source_opt = CaptureScreen_GDI(capture_left, capture_top, capture_right, capture_bottom, params.screen);
		search_offset_x = capture_left;
		search_offset_y = capture_top;
		Source_source = L"Screen";

	}
	else if (params.mode == SearchMode::SearchImageInImage) {
		if (!params.source_image || wcslen(params.source_image) == 0) {
			auto end_time = std::chrono::high_resolution_clock::now();
			auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(end_time - start_time).count();
			result_stream << FormatError(ErrorCode::InvalidParameters);

			if (params.return_debug > 0) {
				std::wstring extra = L"source_image:" + std::wstring(params.source_image ? params.source_image : L"null");
				result_stream << BuildDebugString(duration, params, extra);
			}
			return result_stream.str();
		}

		Source_opt = LoadImageFromFile_GDI(params.source_image);
		Source_source = params.source_image;

	}
	else {
		if (!params.Source_hbitmap) {
			auto end_time = std::chrono::high_resolution_clock::now();
			auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(end_time - start_time).count();
			result_stream << FormatError(ErrorCode::InvalidSourceBitmap);

			if (params.return_debug > 0) {
				std::wstring extra = L"Source_hbitmap:" + std::wstring(params.Source_hbitmap ? L"valid" : L"null")
					+ L",Target_hbitmap:" + std::wstring(params.Target_hbitmap ? L"valid" : L"null");
				result_stream << BuildDebugString(duration, params, extra);
			}
			return result_stream.str();
		}

		Source_opt = GetBitmapPixels_GDI(params.Source_hbitmap);

		if (params.left != 0 || params.top != 0 || params.right != 0 || params.bottom != 0) {
			if (Source_opt && Source_opt->IsValid()) {
				int left = clamp_value(params.left, 0, Source_opt->width - 1);
				int top = clamp_value(params.top, 0, Source_opt->height - 1);
				int right = (params.right <= left || params.right > Source_opt->width) ? Source_opt->width : params.right;
				int bottom = (params.bottom <= top || params.bottom > Source_opt->height) ? Source_opt->height : params.bottom;

				if (left < right && top < bottom) {
					PixelBuffer cropped;
					cropped.width = right - left;
					cropped.height = bottom - top;
					cropped.has_alpha = Source_opt->has_alpha;
					cropped.pixels = g_pixel_pool.Acquire(cropped.width * cropped.height);
					cropped.pixels.resize(cropped.width * cropped.height);

					for (int y = 0; y < cropped.height; ++y) {
						const COLORREF* src_row = &Source_opt->pixels[(top + y) * Source_opt->width + left];
						COLORREF* dst_row = &cropped.pixels[y * cropped.width];
						memcpy(dst_row, src_row, cropped.width * sizeof(COLORREF));
					}

					Source_opt = std::move(cropped);
					search_offset_x = left;
					search_offset_y = top;
				}
			}
		}
		Source_source = L"HBITMAP";
	}

	if (!Source_opt || !Source_opt->IsValid()) {
		auto end_time = std::chrono::high_resolution_clock::now();
		auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(end_time - start_time).count();
		result_stream << FormatError(ErrorCode::FailedToGetScreenDC);

		if (params.return_debug > 0) {
			result_stream << BuildDebugString(duration, params);
		}
		return result_stream.str();
	}

	const PixelBuffer& Source = *Source_opt;

	const wchar_t* target_file_list = nullptr;
	if (params.mode == SearchMode::ScreenSearch) {
		target_file_list = params.image_files;
	}
	else if (params.mode == SearchMode::SearchImageInImage) {
		target_file_list = params.target_images;
	}

	std::vector<std::wstring> target_files;

	if (params.mode == SearchMode::HBitmapSearch) {
		target_files.push_back(L"HBITMAP");
	}
	else if (target_file_list && wcslen(target_file_list) > 0) {
		std::wstring all_files(target_file_list);
		size_t start_pos = 0;
		while (start_pos < all_files.length()) {
			size_t end_pos = all_files.find(L'|', start_pos);
			if (end_pos == std::wstring::npos) {
				end_pos = all_files.length();
			}

			std::wstring file_view = all_files.substr(start_pos, end_pos - start_pos);
			if (!file_view.empty()) {
				target_files.push_back(file_view);
			}

			if (end_pos == all_files.length()) break;
			start_pos = end_pos + 1;
		}
	}

	if (target_files.empty()) {
		auto end_time = std::chrono::high_resolution_clock::now();
		auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(end_time - start_time).count();
		result_stream << FormatError(ErrorCode::InvalidParameters);

		if (params.return_debug > 0) {
			std::wstring extra = L"target_files:" + std::to_wstring(target_files.size());
			result_stream << BuildDebugString(duration, params, extra);
		}
		return result_stream.str();
	}

	std::vector<std::future<Optional<PixelBuffer>>> load_futures;

	if (params.mode == SearchMode::HBitmapSearch) {
		if (params.Target_hbitmap) {
			load_futures.push_back(std::async(std::launch::deferred, [&]() {
				return GetBitmapPixels_GDI(params.Target_hbitmap);
				}));
		}
	}
	else if (target_files.size() > 1) {
		for (const auto& file : target_files) {
			load_futures.push_back(std::async(std::launch::async, [file]() {
				return LoadImageFromFile_GDI(file);
				}));
		}
	}
	else {
		load_futures.push_back(std::async(std::launch::deferred, [&]() {
			return LoadImageFromFile_GDI(target_files[0]);
			}));
	}

	std::vector<MatchResult> all_matches;
	bool find_all = (params.max_results >= 2);
	int cache_hits = 0, cache_misses = 0;
	std::wstring backend_used;

	bool skip_scaling = (std::abs(min_scale - 1.0f) < 0.001f && std::abs(max_scale - 1.0f) < 0.001f);

	for (size_t i = 0; i < load_futures.size(); ++i) {
		auto Target_opt = load_futures[i].get();
		if (!Target_opt || !Target_opt->IsValid()) continue;

		const PixelBuffer& Target = *Target_opt;
		bool transparent_enabled = Target.has_alpha;
		std::wstring source_file = (i < target_files.size()) ? target_files[i] : L"";

		std::vector<MatchResult> current_file_matches;

		if (skip_scaling) {
			std::wstring cache_key;
			if (!source_file.empty() && params.use_cache) {
				cache_key = GenerateCacheKey(Source_source, source_file, tolerance, transparent_enabled, 1.0f);
				// Load cache from disk if not already in memory
				if (!GetCachedLocation(cache_key).has_value()) {
					LoadCacheForImage(cache_key);
				}
			}

			bool found_in_cache = false;

			if (!cache_key.empty() && params.use_cache) {
				auto cached_entry = GetCachedLocation(cache_key);
				if (cached_entry) {
					// Validate cached position is within current search region
					int cached_abs_x = cached_entry->position.x;
					int cached_abs_y = cached_entry->position.y;

					// Check if cached position is within the actual capture bounds
					if (cached_abs_x >= capture_left &&
						cached_abs_y >= capture_top &&
						cached_abs_x + Target.width <= capture_right &&
						cached_abs_y + Target.height <= capture_bottom) {

						int check_x = cached_abs_x - search_offset_x;
						int check_y = cached_abs_y - search_offset_y;

						if (check_x >= 0 && check_y >= 0 &&
							check_x + Target.width <= Source.width &&
							check_y + Target.height <= Source.height) {

							bool found_at_cache = PixelComparison::CheckApproxMatch_Scalar(
								Source, Target, check_x, check_y, transparent_enabled, tolerance);

							if (found_at_cache) {
								current_file_matches.push_back(MatchResult(cached_entry->position.x, cached_entry->position.y,
									Target.width, Target.height, 1.0f, source_file));
								found_in_cache = true;
								cache_hits++;

								CacheEntry updated = *cached_entry;
								updated.miss_count = 0;
								UpdateCachedLocation(cache_key, updated);
							}
							else {
								cache_misses++;
								CacheEntry updated = *cached_entry;
								updated.miss_count++;
								if (updated.miss_count >= CACHE_MISS_THRESHOLD) {
									RemoveFromCache(cache_key);
								}
								else {
									UpdateCachedLocation(cache_key, updated);
								}
							}
						}
					}
					// else: Cached position is outside current search region - skip cache
				}
			}

			// Perform full search if not found in cache or if finding all matches
			// CRITICAL FIX: Always add matches to results, regardless of cache setting
			// Bug: Previously matches were only added when use_cache=1, causing search to fail when use_cache=0
			if (!found_in_cache || find_all) {
				auto matches = SearchForBitmap(Source, Target, search_offset_x, search_offset_y,
					tolerance, transparent_enabled, find_all, 1.0f, source_file, backend_used);

				// Always add matches to results, regardless of cache setting
				if (!matches.empty()) {
					current_file_matches.insert(current_file_matches.end(), matches.begin(), matches.end());

					// Save to cache only if caching is enabled
					if (params.use_cache && !cache_key.empty()) {
						POINT new_pos = { matches[0].x, matches[0].y };
						CacheEntry entry;
						entry.position = new_pos;
						entry.miss_count = 0;
						entry.last_used = std::chrono::steady_clock::now();
						UpdateCachedLocation(cache_key, entry);
						SaveCacheForImage(cache_key, new_pos);
					}
				}
			}
		}
		else {
			std::vector<float> scales;
			for (float scale = min_scale; scale <= max_scale; scale += scale_step) {
				scales.push_back(std::round(scale * 10.0f) / 10.0f);
			}

			if (find_all && scales.size() > 1) {
				std::vector<std::future<std::vector<MatchResult>>> scale_futures;

				for (float scale : scales) {
					scale_futures.push_back(std::async(std::launch::async, [&, scale]() {
						std::vector<MatchResult> scale_matches;

						int newW = static_cast<int>(std::round(Target.width * scale));
						int newH = static_cast<int>(std::round(Target.height * scale));
						if (newW <= 0 || newH <= 0 || newW > Source.width || newH > Source.height) {
							return scale_matches;
						}

						auto scaled_opt = ScaleBitmap_GDI(Target, newW, newH);
						if (scaled_opt && scaled_opt->IsValid()) {
							std::wstring thread_backend;
							scale_matches = SearchForBitmap(Source, *scaled_opt, search_offset_x, search_offset_y,
								tolerance, transparent_enabled, true, scale, source_file, thread_backend);
						}
						return scale_matches;
						}));
				}

				for (auto& fut : scale_futures) {
					auto scale_results = fut.get();
					if (!scale_results.empty()) {
						current_file_matches.insert(current_file_matches.end(), scale_results.begin(), scale_results.end());
					}
				}

			}
			else {
				for (float scale : scales) {
					int newW = static_cast<int>(std::round(Target.width * scale));
					int newH = static_cast<int>(std::round(Target.height * scale));
					if (newW <= 0 || newH <= 0 || newW > Source.width || newH > Source.height) {
						continue;
					}

					auto scaled_opt = ScaleBitmap_GDI(Target, newW, newH);
					if (scaled_opt && scaled_opt->IsValid()) {
						auto matches = SearchForBitmap(Source, *scaled_opt, search_offset_x, search_offset_y,
							tolerance, transparent_enabled, find_all, scale, source_file, backend_used);
						if (!matches.empty()) {
							current_file_matches.insert(current_file_matches.end(), matches.begin(), matches.end());
							if (!find_all) break;
						}
					}
				}
			}
		}

		if (!current_file_matches.empty()) {
			all_matches.insert(all_matches.end(), current_file_matches.begin(), current_file_matches.end());
			if (!find_all) break;
		}
	}

	auto end_time = std::chrono::high_resolution_clock::now();
	auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(end_time - start_time).count();

	// Limit results if needed
	std::vector<MatchResult> limited_matches = all_matches;
	if (params.max_results > 0 && limited_matches.size() > static_cast<size_t>(params.max_results)) {
		limited_matches.resize(params.max_results);
	}

	// Use helper function to format results
	result_stream << FormatMatchResults(limited_matches, params.center_pos);

	// OPTIMIZATION: Use stringstream instead of string concatenation
	// Previous version: 15+ string concatenations → 15+ temporary objects
	// New version: Single allocation at end → ~20% faster, less memory pressure
	std::wstring debug_info;
	if (params.return_debug > 0) {
		std::wstringstream ss;
		ss << L"(time=" << duration << L"ms"
		   << L", backend=" << backend_used
		   << L", Source=" << Source.width << L"x" << Source.height
		   << L", files=" << target_files.size()
		   << L", cache_hits=" << cache_hits
		   << L", cache_misses=" << cache_misses
		   << L", tolerance=" << tolerance
		   << L", scale=" << FormatFloat(min_scale) << L"-" << FormatFloat(max_scale) << L":" << FormatFloat(scale_step)
#ifdef _WIN64
		   << L", cpu=AVX2:" << (g_is_avx2_supported.load() ? L"Y" : L"N")
		   << L"/AVX512:" << (g_is_avx512_supported.load() ? L"Y" : L"N")
#else
		   << L", cpu=SSE2:" << (g_is_sse2_supported.load() ? L"Y" : L"N")
#endif
		   << L", capture=" << capture_left << L"|" << capture_top << L"|" << capture_right << L"|" << capture_bottom
		   << L"|" << capture_width << L"x" << capture_height
		   << L", screen=" << params.screen
		   << L")";
		debug_info = ss.str();
	}

	if (!debug_info.empty()) {
		result_stream << debug_info;
	}

	return result_stream.str();
}

// Helper: Check and handle result buffer overflow
static void CheckResultBufferSize(std::wstring& result_buffer, const SearchParams& params) {
	if (result_buffer.length() >= MAX_RESULT_STRING_LENGTH) {
		result_buffer = FormatError(ErrorCode::ResultTooLarge);

		if (params.return_debug > 0) {
			std::wstring extra_info = L"buffer_size=" + std::to_wstring(result_buffer.length());
			result_buffer += BuildDebugString(0, params, extra_info);
		}
	}
}

// ============================================================================
// HELPER: ScreenToAbsolute (Legacy wrapper)
// ============================================================================
// Description:
//   Converts screen coordinates to absolute coordinates for mouse input.
//   This is now a wrapper around CreateMouseInput for consistency.
//   Kept for backward compatibility with existing code.
// ============================================================================
static void ScreenToAbsolute(int x, int y, LONG& ax, LONG& ay) {
	LONG64 screenWidth = GetSystemMetrics(SM_CXVIRTUALSCREEN);
	LONG64 screenHeight = GetSystemMetrics(SM_CYVIRTUALSCREEN);
	if (screenWidth <= 0)  screenWidth = 1;
	if (screenHeight <= 0) screenHeight = 1;

	LONG64 ax_temp = (static_cast<LONG64>(x) * 65535LL) / screenWidth;
	LONG64 ay_temp = (static_cast<LONG64>(y) * 65535LL) / screenHeight;

	ax = static_cast<LONG>(clamp_value(ax_temp, 0LL, 65535LL));
	ay = static_cast<LONG>(clamp_value(ay_temp, 0LL, 65535LL));
}

// Helper function to get mouse button flags
static void GetMouseButtonFlags(const wchar_t* button, DWORD& downFlag, DWORD& upFlag) {
	std::wstring btn = button;
	for (size_t i = 0; i < btn.length(); ++i) {
		btn[i] = towlower(btn[i]);
	}

	if (btn == L"left" || btn == L"main" || btn == L"primary") {
		downFlag = MOUSEEVENTF_LEFTDOWN;
		upFlag = MOUSEEVENTF_LEFTUP;
	}
	else if (btn == L"right" || btn == L"menu" || btn == L"secondary") {
		downFlag = MOUSEEVENTF_RIGHTDOWN;
		upFlag = MOUSEEVENTF_RIGHTUP;
	}
	else if (btn == L"middle") {
		downFlag = MOUSEEVENTF_MIDDLEDOWN;
		upFlag = MOUSEEVENTF_MIDDLEUP;
	}
	else {
		downFlag = MOUSEEVENTF_LEFTDOWN;
		upFlag = MOUSEEVENTF_LEFTUP;
	}
}

// Helper function to move mouse smoothly
static void SmoothMouseMove(int startX, int startY, int endX, int endY, int speed) {
	if (speed == 0) {
		SetCursorPos(endX, endY);
		return;
	}

	// Speed: 1 = fastest (few steps), 100 = slowest (many steps)
	int steps = (speed > 1) ? speed : 1;
	int deltaX = endX - startX;
	int deltaY = endY - startY;
	double distance = std::sqrt(static_cast<double>(deltaX * deltaX + deltaY * deltaY));

	if (distance < 1.0) {
		SetCursorPos(endX, endY);
		return;
	}

	// Calculate delay between steps based on speed
	int totalDelay = speed * 2; // Total time in ms
	int delayPerStep = totalDelay / steps;
	if (delayPerStep < 1) delayPerStep = 1;

	for (int i = 1; i <= steps; i++) {
		int x = startX + (deltaX * i) / steps;
		int y = startY + (deltaY * i) / steps;
		SetCursorPos(x, y);
		Sleep(delayPerStep);
	}
}

// Fallback: Click using mouse_event
static void PerformClick_MouseEvent(const wchar_t* button, int clicks) {
	DWORD downFlag = 0, upFlag = 0;
	GetMouseButtonFlags(button, downFlag, upFlag);

	for (int i = 0; i < clicks; i++) {
		mouse_event(downFlag, 0, 0, 0, 0);
		Sleep(10);
		mouse_event(upFlag, 0, 0, 0, 0);
		if (i < clicks - 1) {
			Sleep(50);
		}
	}
}

// Enhanced click function using SendInput with fallback to mouse_event
static bool PerformClick(int x, int y, const wchar_t* button, int clicks, int speed, bool restorePosition) {
	POINT currentPos;
	GetCursorPos(&currentPos);

	DWORD downFlag = 0, upFlag = 0;
	GetMouseButtonFlags(button, downFlag, upFlag);

	bool useFallback = false;

	// Move to position if needed
	if (speed == 0) {
		// Instant move using SendInput with absolute coordinates
		INPUT moveInput = CreateMouseInput(x, y, MOUSEEVENTF_MOVE | MOUSEEVENTF_ABSOLUTE);
		
		if (SendInput(1, &moveInput, sizeof(INPUT)) != 1) {
			// Fallback to SetCursorPos
			SetCursorPos(x, y);
			useFallback = true;
		}
		Sleep(5);
	}
	else {
		// Smooth move
		SmoothMouseMove(currentPos.x, currentPos.y, x, y, speed);
	}

	// Perform clicks
	if (!useFallback) {
		for (int i = 0; i < clicks; i++) {
			INPUT inputs[2];
			ZeroMemory(inputs, sizeof(inputs));

			// Mouse down
			inputs[0].type = INPUT_MOUSE;
			inputs[0].mi.dwFlags = downFlag;
			inputs[0].mi.dwExtraInfo = 0;

			// Mouse up
			inputs[1].type = INPUT_MOUSE;
			inputs[1].mi.dwFlags = upFlag;
			inputs[1].mi.dwExtraInfo = 0;

			// Send down
			if (SendInput(1, &inputs[0], sizeof(INPUT)) != 1) {
				// Fallback to mouse_event for remaining clicks
				useFallback = true;
				PerformClick_MouseEvent(button, clicks - i);
				break;
			}
			Sleep(10);

			// Send up
			if (SendInput(1, &inputs[1], sizeof(INPUT)) != 1) {
				// Fallback to mouse_event for remaining clicks
				useFallback = true;
				// Already sent down, so just send up and continue
				mouse_event(upFlag, 0, 0, 0, 0);
				if (i < clicks - 1) {
					Sleep(50);
					PerformClick_MouseEvent(button, clicks - i - 1);
				}
				break;
			}

			if (i < clicks - 1) {
				Sleep(50);
			}
		}
	}
	else {
		// Use mouse_event fallback
		PerformClick_MouseEvent(button, clicks);
	}

	// Restore position if needed
	if (restorePosition) {
		Sleep(10);

		INPUT moveInput = CreateMouseInput(currentPos.x, currentPos.y, MOUSEEVENTF_MOVE | MOUSEEVENTF_ABSOLUTE);
		
		if (SendInput(1, &moveInput, sizeof(INPUT)) != 1) {
			// Fallback to SetCursorPos
			SetCursorPos(currentPos.x, currentPos.y);
		}
	}

	return true;
}

// Helper structure for text search in child windows
struct TextSearchData {
	const wchar_t* text;
	bool found;

	TextSearchData() : text(NULL), found(false) {}
};

// Callback for EnumChildWindows in text search
static BOOL CALLBACK EnumChildWindowsTextProc(HWND hwndChild, LPARAM lParam) {
	TextSearchData* data = reinterpret_cast<TextSearchData*>(lParam);
	wchar_t controlText[1024];
	memset(controlText, 0, sizeof(controlText));
	GetWindowTextW(hwndChild, controlText, 1024);
	if (wcsstr(controlText, data->text) != NULL) {
		data->found = true;
		return FALSE; // Found, stop enumeration
	}
	return TRUE;
}

// Helper function to check if window/controls contain text
static bool WindowContainsText(HWND hWnd, const wchar_t* searchText) {
	if (!searchText || wcslen(searchText) == 0) {
		return true; // No text to search, consider as match
	}

	// Check window itself first (fastest)
	wchar_t windowText[1024];
	memset(windowText, 0, sizeof(windowText));
	GetWindowTextW(hWnd, windowText, 1024);
	if (wcsstr(windowText, searchText) != NULL) {
		return true;
	}

	// Check in child controls
	TextSearchData searchData;
	searchData.text = searchText;
	searchData.found = false;

	EnumChildWindows(hWnd, EnumChildWindowsTextProc, reinterpret_cast<LPARAM>(&searchData));

	return searchData.found;
}

// Helper structure for window candidate
struct WindowCandidate {
	HWND hwnd;
	std::wstring title;
	int titleMatchQuality; // 0=exact, 1=starts_with, 2=contains

	WindowCandidate() : hwnd(NULL), title(L""), titleMatchQuality(0) {}
};

// Helper structure for window enumeration
struct WindowEnumData {
	const wchar_t* searchTitle;
	std::vector<WindowCandidate>* candidatesList;

	WindowEnumData() : searchTitle(NULL), candidatesList(NULL) {}
};

// Callback for EnumWindows
static BOOL CALLBACK EnumWindowsProc(HWND hwnd, LPARAM lParam) {
	WindowEnumData* data = reinterpret_cast<WindowEnumData*>(lParam);
	const wchar_t* searchTitle = data->searchTitle;
	std::vector<WindowCandidate>* candidatesList = data->candidatesList;

	// Only check visible windows
	if (!IsWindowVisible(hwnd)) {
		return TRUE;
	}

	wchar_t windowTitle[1024];
	memset(windowTitle, 0, sizeof(windowTitle));
	int titleLen = GetWindowTextW(hwnd, windowTitle, 1024);

	if (titleLen == 0) {
		return TRUE;
	}

	// Check if title matches (partial substring)
	const wchar_t* matchPos = wcsstr(windowTitle, searchTitle);
	if (matchPos != NULL) {
		WindowCandidate candidate;
		candidate.hwnd = hwnd;
		candidate.title = windowTitle;

		// Determine match quality
		if (wcscmp(windowTitle, searchTitle) == 0) {
			candidate.titleMatchQuality = 0; // Exact match
		}
		else if (matchPos == windowTitle) {
			candidate.titleMatchQuality = 1; // Starts with
		}
		else {
			candidate.titleMatchQuality = 2; // Contains
		}

		candidatesList->push_back(candidate);
	}

	return TRUE; // Continue enumeration
}

// Comparison function for sorting candidates
static bool CompareWindowCandidates(const WindowCandidate& a, const WindowCandidate& b) {
	return a.titleMatchQuality < b.titleMatchQuality;
}

// Helper function to find window by title, text, or handle
static HWND FindTargetWindow(const wchar_t* title, const wchar_t* text) {
	if (!title || wcslen(title) == 0) return NULL;

	HWND hWnd = NULL;

	// Try to parse as HWND (hexadecimal or decimal)
	if (wcsncmp(title, L"0x", 2) == 0) {
		hWnd = reinterpret_cast<HWND>(_wcstoui64(title, NULL, 16));
	}
	else if (iswdigit(title[0])) {
		hWnd = reinterpret_cast<HWND>(_wcstoui64(title, NULL, 10));
	}

	// Validate if parsed as HWND and check if visible
	if (hWnd && IsWindow(hWnd) && IsWindowVisible(hWnd)) {
		if (WindowContainsText(hWnd, text)) {
			return hWnd;
		}
		return NULL;
	}

	// Step 1: Try exact title match first (fastest)
	hWnd = FindWindowW(NULL, title);
	if (hWnd && IsWindow(hWnd) && IsWindowVisible(hWnd)) {
		if (WindowContainsText(hWnd, text)) {
			return hWnd; // Found with exact title and text match
		}
	}

	// Step 2: Try exact class name match
	hWnd = FindWindowW(title, NULL);
	if (hWnd && IsWindow(hWnd) && IsWindowVisible(hWnd)) {
		if (WindowContainsText(hWnd, text)) {
			return hWnd; // Found with exact class and text match
		}
	}

	// Step 3: Collect all windows with partial title match
	std::vector<WindowCandidate> candidates;

	WindowEnumData enumData;
	enumData.searchTitle = title;
	enumData.candidatesList = &candidates;

	EnumWindows(EnumWindowsProc, reinterpret_cast<LPARAM>(&enumData));

	// If no candidates found, return NULL
	if (candidates.empty()) {
		return NULL;
	}

	// Step 4: Sort candidates by match quality (best matches first)
	std::sort(candidates.begin(), candidates.end(), CompareWindowCandidates);

	// Step 5: Check text in candidates (best matches first)
	for (size_t i = 0; i < candidates.size(); ++i) {
		if (WindowContainsText(candidates[i].hwnd, text)) {
			return candidates[i].hwnd; // Found first window with title and text match
		}
	}

	// No window found with both title and text match
	return NULL;
}

// ============================================================================
// EXPORTED FUNCTION: Mouse_Click
// ============================================================================
// Description:
//   Simulates mouse click at specified coordinates with configurable parameters.
//   Supports smooth mouse movement and multiple click modes.
//
// Parameters:
//   sButton  - Mouse button to click:
//              * "left", "main", "primary" = Left mouse button
//              * "right", "menu", "secondary" = Right mouse button
//              * "middle" = Middle mouse button
//   iX       - X coordinate (-1 = current position, no movement)
//   iY       - Y coordinate (-1 = current position, no movement)
//   iClicks  - Number of clicks to perform (1 = single, 2 = double, etc.)
//   iSpeed   - Mouse movement speed (0-100):
//              * 0   = Instant teleport (no smooth movement)
//              * 1   = Fastest smooth movement
//              * 100 = Slowest smooth movement
//   iScreen  - Coordinate system (same as ImageSearch):
//              * 0  = Absolute screen coordinates
//              * >0 = Relative to specific monitor (1-based)
//              * <0 = Relative to virtual screen
//
// Returns:
//   1 on success, 0 on failure
//
// Behavior:
//   - When iSpeed = 0 and coordinates provided, cursor position is restored after click
//   - Uses SendInput API with fallback to mouse_event for compatibility
//   - Supports multi-monitor setups with proper coordinate translation
//
// Example:
//   // Double-click at (100, 200) on primary monitor with smooth movement
//   Mouse_Click(L"left", 100, 200, 2, 50, 0);
// ============================================================================
extern "C" __declspec(dllexport) int WINAPI Mouse_Click(
	const wchar_t* sButton,
	int iX,
	int iY,
	int iClicks,
	int iSpeed,
	int iScreen
) {
	ScopedDpiAwareness dpiScope;
	if (!sButton) return 0;

	if (iClicks < 1) iClicks = 1;
	if (iSpeed < 0) iSpeed = 0;
	if (iSpeed > 100) iSpeed = 100;

	POINT currentPos;
	GetCursorPos(&currentPos);

	bool needMove = (iX != -1 && iY != -1);
	bool restorePosition = (iSpeed == 0 && needMove);

	int targetX = currentPos.x;
	int targetY = currentPos.y;

	if (needMove) {
		if (iScreen > 0) {
			// iScreen > 0: Coordinates relative to specific monitor
			RECT monitorBounds;
			if (GetMonitorBounds(iScreen, monitorBounds)) {
				targetX = monitorBounds.left + iX;
				targetY = monitorBounds.top + iY;
			}
			else {
				// Fallback if monitor bounds unavailable
				targetX = iX;
				targetY = iY;
			}
		}
		else {
			// iScreen <= 0: Coordinates are already absolute (no offset needed)
			// FIX: DLL returns absolute virtual coordinates, don't add offset again
			targetX = iX;
			targetY = iY;
		}

		PerformClick(targetX, targetY, sButton, iClicks, iSpeed, restorePosition);
	}
	else {
		PerformClick(currentPos.x, currentPos.y, sButton, iClicks, iSpeed, false);
	}

	return 1;
}

// ============================================================================
// EXPORTED FUNCTION: Mouse_Move
// ============================================================================
// Description:
//   Moves mouse cursor to specified screen coordinates with optional smooth movement.
//   Supports multi-monitor setups and virtual desktop coordinates (including negative).
//
// Parameters:
//   iX, iY   - Target coordinates (-1 = keep current position)
//   iSpeed   - Movement speed 0-100 (0=instant, 100=slowest)
//   iScreen  - Monitor selection:
//              * 0  = Primary monitor coordinates (default)
//              * >0 = Relative to specific monitor (1-based)
//              * <0 = Relative to virtual screen (supports negative coords)
//
// Returns:
//   1 on success, 0 on failure
//
// Example:
//   // Move to (-274, -416) on virtual desktop instantly
//   Mouse_Move(-274, -416, 0, -1);
// ============================================================================
extern "C" __declspec(dllexport) int WINAPI Mouse_Move(
	int iX,
	int iY,
	int iSpeed,
	int iScreen
) {
	ScopedDpiAwareness dpiScope;
	if (iSpeed < 0) iSpeed = 0;
	if (iSpeed > 100) iSpeed = 100;

	POINT currentPos;
	GetCursorPos(&currentPos);

	// If no coordinates specified, nothing to do
	if (iX == -1 && iY == -1) return 1;

	int targetX = currentPos.x;
	int targetY = currentPos.y;

	// Calculate target coordinates based on iScreen
	if (iScreen > 0) {
		// iScreen > 0: Coordinates relative to specific monitor
		RECT monitorBounds;
		if (GetMonitorBounds(iScreen, monitorBounds)) {
			targetX = (iX != -1) ? (monitorBounds.left + iX) : currentPos.x;
			targetY = (iY != -1) ? (monitorBounds.top + iY) : currentPos.y;
		}
		else {
			// Fallback if monitor bounds unavailable
			targetX = (iX != -1) ? iX : currentPos.x;
			targetY = (iY != -1) ? iY : currentPos.y;
		}
	}
	else {
		// iScreen <= 0: Coordinates are already absolute (no offset needed)
		targetX = (iX != -1) ? iX : currentPos.x;
		targetY = (iY != -1) ? iY : currentPos.y;
	}

	// Perform move
	if (iSpeed == 0) {
		// Instant move using SendInput with absolute coordinates
		INPUT moveInput = CreateMouseInput(targetX, targetY, MOUSEEVENTF_MOVE | MOUSEEVENTF_ABSOLUTE);
		
		if (SendInput(1, &moveInput, sizeof(INPUT)) != 1) {
			// Fallback to SetCursorPos
			SetCursorPos(targetX, targetY);
		}
	}
	else {
		// Smooth move
		SmoothMouseMove(currentPos.x, currentPos.y, targetX, targetY, iSpeed);
	}

	return 1;
}

// ============================================================================
// EXPORTED FUNCTION: Mouse_ClickWin
// ============================================================================
// Description:
//   Clicks at coordinates relative to a specific window.
//   Finds window by title/class and optionally validates by text content.
//
// Parameters:
//   sTitle  - Window title, class name, or HWND (as decimal/hex string):
//             * Window title (partial match supported)
//             * Window class name
//             * "0x123ABC" or "123456" = Direct HWND handle
//   sText   - Optional text that must exist in window/controls (empty = any)
//   iX      - X coordinate relative to window's top-left corner
//   iY      - Y coordinate relative to window's top-left corner
//   sButton - Mouse button ("left", "right", "middle")
//   iClicks - Number of clicks (1, 2, 3, ...)
//   iSpeed  - Movement speed (0-100, same as Mouse_Click)
//
// Returns:
//   1 on success, 0 on failure (window not found, coordinates out of bounds)
//
// Window Search Priority:
//   1. Try exact title match
//   2. Try exact class name match
//   3. Enumerate all windows for partial title match
//   4. Best match is selected (exact > starts_with > contains)
//   5. Validate found window contains sText (if specified)
//
// Coordinate Validation:
//   Click coordinates must be within window bounds, otherwise function fails.
//
// Example:
//   // Click "OK" button in "Settings" window at position (100, 50)
//   Mouse_ClickWin(L"Settings", L"OK", 100, 50, L"left", 1, 0);
// ============================================================================
extern "C" __declspec(dllexport) int WINAPI Mouse_ClickWin(
	const wchar_t* sTitle,
	const wchar_t* sText,
	int iX,
	int iY,
	const wchar_t* sButton,
	int iClicks,
	int iSpeed
) {
	ScopedDpiAwareness dpiScope;
	if (!sTitle || wcslen(sTitle) == 0) return 0;
	if (!sButton) sButton = L"left";

	// Find target window
	HWND hWnd = FindTargetWindow(sTitle, sText);
	if (!hWnd || !IsWindow(hWnd)) return 0;

	// Get window rectangle
	RECT rect;
	if (!GetWindowRect(hWnd, &rect)) return 0;

	// Calculate absolute screen coordinates
	int screenX = rect.left + iX;
	int screenY = rect.top + iY;

	// Validate coordinates are within window bounds
	if (screenX < rect.left || screenX > rect.right ||
		screenY < rect.top || screenY > rect.bottom) {
		return 0; // Click position outside window
	}

	// Clamp parameters
	if (iClicks < 1) iClicks = 1;
	if (iSpeed < 0) iSpeed = 0;
	if (iSpeed > 100) iSpeed = 100;

	bool restorePosition = (iSpeed == 0);

	// Perform click with SendInput (auto-fallback to mouse_event if fail)
	PerformClick(screenX, screenY, sButton, iClicks, iSpeed, restorePosition);

	return 1;
}

// ============================================================================
// EXPORTED FUNCTION: ImageSearch
// ============================================================================
// Description:
//   Main function to search for image(s) on the screen within a specified region.
//   Supports multi-image search, scaling, transparency, and caching.
//
// Parameters:
//   sImageFile   - Pipe-separated list of image file paths to search for (e.g., "img1.png|img2.png")
//   iLeft        - Left boundary of search region (screen coordinates)
//   iTop         - Top boundary of search region (screen coordinates)
//   iRight       - Right boundary of search region (0 = screen width)
//   iBottom      - Bottom boundary of search region (0 = screen height)
//   iScreen      - Screen/monitor selection:
//                  * 0  = Use absolute coordinates (no bounds adjustment)
//                  * >0 = Specific monitor number (1-based, e.g., 1 = primary, 2 = secondary)
//                  * <0 = Virtual screen (all monitors combined)
//   iTolerance   - Color matching tolerance (0-255, default 10)
//                  * 0   = Exact match required
//                  * 255 = Maximum tolerance (any color matches)
//   iResults     - Maximum number of results to return (1 = find first, >=2 = find all)
//   iCenterPOS   - Return position mode:
//                  * 1 = Return center coordinates of found image
//                  * 0 = Return top-left coordinates
//   fMinScale    - Minimum scale factor for search (0.1-5.0, default 1.0 = 100%)
//   fMaxScale    - Maximum scale factor for search (0.1-5.0, default 1.0 = 100%)
//   fScaleStep   - Scale increment step (0.01-1.0, default 0.1 = 10%)
//   iReturnDebug - Enable debug info in result string (0 = off, 1 = on)
//   iUseCache    - Enable location caching for faster repeated searches (0 = off, 1 = on)
//
// Returns:
//   Wide string with format: "{count}[x|y|w|h,x|y|w|h,...]"
//   Examples:
//     Success:  "{1}[100|200|50|30]" - Found 1 match at (100,200) with size 50x30
//     Multiple: "{2}[100|200|50|30,150|250|50|30]" - Found 2 matches
//     No match: "{0}[]"
//     Error:    "ERROR: <error_message>"
//
// Thread Safety:
//   Thread-safe. Uses thread_local storage for result buffer.
//
// Performance:
//   - Automatically selects SIMD backend (AVX512/AVX2/SSE2/Scalar)
//   - Supports multi-threading for large images
//   - Cache system reduces search time for repeated patterns
// ============================================================================
extern "C" __declspec(dllexport) const wchar_t* WINAPI ImageSearch(
	const wchar_t* sImageFile,
	int iLeft = 0,
	int iTop = 0,
	int iRight = 0,
	int iBottom = 0,
	int iScreen = 0,
	int iTolerance = 10,
	int iResults = 1,
	int iCenterPOS = 1,
	float fMinScale = 1.0f,
	float fMaxScale = 1.0f,
	float fScaleStep = 0.1f,
	int iReturnDebug = 0,
	int iUseCache = 0
) {
	thread_local std::wstring result_buffer;

	SearchParams params;
	params.mode = SearchMode::ScreenSearch;
	params.image_files = sImageFile;
	params.left = iLeft;
	params.top = iTop;
	params.right = iRight;
	params.bottom = iBottom;
	params.screen = iScreen;
	params.tolerance = iTolerance;
	params.max_results = iResults;
	params.center_pos = iCenterPOS;
	params.min_scale = fMinScale;
	params.max_scale = fMaxScale;
	params.scale_step = fScaleStep;
	params.return_debug = iReturnDebug;
	params.use_cache = iUseCache;

	result_buffer = UnifiedImageSearch(params);

	CheckResultBufferSize(result_buffer, params);

	return result_buffer.c_str();
}

// ============================================================================
// EXPORTED FUNCTION: Search_In_Image
// ============================================================================
// Description:
//   Search for target image(s) within a source image file.
//   Useful for offline image analysis without screen capture.
//
// Parameters:
//   sSourceImageFile - Path to source image file to search within
//   sTargetImageFile - Pipe-separated list of target image paths to find
//   iTolerance       - Color matching tolerance (0-255, default 10)
//   iResults         - Maximum results (1 = first match, >=2 = all matches)
//   iCenterPOS       - Position mode (1 = center, 0 = top-left)
//   fMinScale        - Minimum scale factor (0.1-5.0, default 1.0)
//   fMaxScale        - Maximum scale factor (0.1-5.0, default 1.0)
//   fScaleStep       - Scale increment (0.01-1.0, default 0.1)
//   iReturnDebug     - Debug info flag (0 = off, 1 = on)
//   iUseCache        - Caching flag (0 = off, 1 = on)
//
// Returns:
//   Same format as ImageSearch: "{count}[x|y|w|h,...]"
//   Coordinates are relative to source image origin (0,0)
//
// Use Cases:
//   - Template matching in saved screenshots
//   - Batch image processing
//   - Testing/validation without screen dependency
// ============================================================================
extern "C" __declspec(dllexport) const wchar_t* WINAPI Search_In_Image(
	const wchar_t* sSourceImageFile,
	const wchar_t* sTargetImageFile,
	int iTolerance = 10,
	int iResults = 1,
	int iCenterPOS = 1,
	float fMinScale = 1.0f,
	float fMaxScale = 1.0f,
	float fScaleStep = 0.1f,
	int iReturnDebug = 0,
	int iUseCache = 0
) {
	thread_local std::wstring result_buffer;

	SearchParams params;
	params.mode = SearchMode::SearchImageInImage;
	params.source_image = sSourceImageFile;
	params.target_images = sTargetImageFile;
	params.tolerance = iTolerance;
	params.max_results = iResults;
	params.center_pos = iCenterPOS;
	params.min_scale = fMinScale;
	params.max_scale = fMaxScale;
	params.scale_step = fScaleStep;
	params.return_debug = iReturnDebug;
	params.use_cache = iUseCache;

	result_buffer = UnifiedImageSearch(params);

	CheckResultBufferSize(result_buffer, params);

	return result_buffer.c_str();
}

extern "C" __declspec(dllexport) const wchar_t* WINAPI hBitmap_Search(
	HBITMAP hBitmapSource,
	HBITMAP hBitmapTarget,
	int iTolerance,
	int iLeft,
	int iTop,
	int iRight,
	int iBottom,
	int iResults = 1,
	int iCenter = 1,
	float fMinScale = 1.0f,
	float fMaxScale = 1.0f,
	float fScaleStep = 0.1f,
	int iReturnDebug = 0,
	int iUseCache = 0
) {
	thread_local std::wstring result_buffer;

	SearchParams params;
	params.mode = SearchMode::HBitmapSearch;
	params.Source_hbitmap = hBitmapSource;
	params.Target_hbitmap = hBitmapTarget;
	params.left = iLeft;
	params.top = iTop;
	params.right = iRight;
	params.bottom = iBottom;
	params.tolerance = iTolerance;
	params.max_results = iResults;
	params.center_pos = iCenter;
	params.min_scale = fMinScale;
	params.max_scale = fMaxScale;
	params.scale_step = fScaleStep;
	params.return_debug = iReturnDebug;
	params.use_cache = iUseCache;

	result_buffer = UnifiedImageSearch(params);

	CheckResultBufferSize(result_buffer, params);

	return result_buffer.c_str();
}

// ============================================================================
// EXPORTED FUNCTION: Capture_Screen
// ============================================================================
// Description:
//   Captures a screen region and returns it as an HBITMAP handle.
//   The returned bitmap can be used with hBitmap_Search or saved.
//
// Parameters:
//   iLeft   - Left boundary of capture region
//   iTop    - Top boundary of capture region
//   iRight  - Right boundary (0 = screen width)
//   iBottom - Bottom boundary (0 = screen height)
//   iScreen - Screen selection (same as ImageSearch)
//
// Returns:
//   HBITMAP handle to captured screen region, or NULL on failure
//
// IMPORTANT:
//   Caller is responsible for deleting the returned HBITMAP using DeleteObject()
//   to prevent memory leaks.
//
// Example:
//   HBITMAP hBmp = Capture_Screen(0, 0, 800, 600, 0);
//   if (hBmp) {
//       // Use bitmap...
//       DeleteObject(hBmp); // Clean up!
//   }
// ============================================================================
extern "C" __declspec(dllexport) HBITMAP WINAPI Capture_Screen(
	int iLeft = 0,
	int iTop = 0,
	int iRight = 0,
	int iBottom = 0,
	int iScreen = 0
) {
	InitializeGdiplus();
	return CaptureScreenInternal(iLeft, iTop, iRight, iBottom, iScreen);
}

// ============================================================================
// EXPORTED FUNCTION: hBitmap_Load
// ============================================================================
// Description:
//   Loads an image file and converts it to HBITMAP with optional background color.
//   Useful for loading images to use with hBitmap_Search.
//
// Parameters:
//   sImageFile - Path to image file (supports: PNG, JPG, BMP, GIF, TIFF)
//   iAlpha     - Background alpha channel (0-255, 0 = transparent)
//   iRed       - Background red component (0-255)
//   iGreen     - Background green component (0-255)
//   iBlue      - Background blue component (0-255)
//
// Returns:
//   HBITMAP handle to loaded image, or NULL on failure
//
// Background Color Usage:
//   The ARGB values are used as background when converting the image.
//   For images with transparency, the background color fills transparent areas.
//   Default (0,0,0,0) creates a black transparent background.
//
// IMPORTANT:
//   Caller must call DeleteObject() on returned HBITMAP to prevent memory leaks.
//
// Example:
//   // Load image with white background
//   HBITMAP hBmp = hBitmap_Load(L"logo.png", 255, 255, 255, 255);
//   if (hBmp) {
//       // Use bitmap...
//       DeleteObject(hBmp); // Clean up!
//   }
// ============================================================================
extern "C" __declspec(dllexport) HBITMAP WINAPI hBitmap_Load(
	const wchar_t* sImageFile,
	int iAlpha = 0,
	int iRed = 0,
	int iGreen = 0,
	int iBlue = 0
) {
	if (!sImageFile || wcslen(sImageFile) == 0) {
		return nullptr;
	}

	// Check if file exists
	if (!FileSystem::exists(sImageFile)) {
		return nullptr;
	}

	InitializeGdiplus();

	// Load bitmap from file
	auto bitmap = std::make_unique<Bitmap>(sImageFile);
	if (!bitmap || bitmap->GetLastStatus() != Ok) {
		return nullptr;
	}

	int width = bitmap->GetWidth();
	int height = bitmap->GetHeight();
	if (width <= 0 || height <= 0 || width > 32000 || height > 32000) {
		return nullptr;
	}

	// Clamp color values to valid range (0-255)
	int alpha = clamp_value(iAlpha, 0, 255);
	int red = clamp_value(iRed, 0, 255);
	int green = clamp_value(iGreen, 0, 255);
	int blue = clamp_value(iBlue, 0, 255);

	// Create background color from ARGB
	Color background(alpha, red, green, blue);

	// Convert to HBITMAP
	HBITMAP hBitmap = nullptr;
	if (bitmap->GetHBITMAP(background, &hBitmap) != Ok) {
		return nullptr;
	}

	return hBitmap;
}

// ============================================================================
// HELPER FUNCTION: GetEncoderClsid
// ============================================================================
// Description:
//   Gets the CLSID for an image encoder based on MIME type.
//   Used internally for saving images in different formats.
//
// Parameters:
//   format - MIME type string (e.g., L"image/bmp", L"image/png", L"image/jpeg")
//   pClsid - Pointer to CLSID to receive the encoder CLSID
//
// Returns:
//   Index of encoder (>=0) on success, -1 on failure
//
// OPTIMIZATION: Uses RAII (unique_ptr) instead of manual malloc/free
// This prevents memory leaks if exception is thrown in loop
// ============================================================================
static int GetEncoderClsid(const wchar_t* format, CLSID* pClsid) {
	UINT num = 0;        // Number of image encoders
	UINT size = 0;       // Size of the image encoder array in bytes
	
	Gdiplus::GetImageEncodersSize(&num, &size);
	if (size == 0) return -1;
	
	// RAII: Automatically freed when out of scope (exception-safe)
	std::unique_ptr<BYTE[]> buffer(new(std::nothrow) BYTE[size]);
	if (!buffer) return -1;
	
	auto* pImageCodecInfo = reinterpret_cast<Gdiplus::ImageCodecInfo*>(buffer.get());
	Gdiplus::GetImageEncoders(num, size, pImageCodecInfo);
	
	for (UINT j = 0; j < num; ++j) {
		if (wcscmp(pImageCodecInfo[j].MimeType, format) == 0) {
			*pClsid = pImageCodecInfo[j].Clsid;
			return j;  // Success (buffer auto-freed)
		}
	}
	
	return -1;  // Encoder not found (buffer auto-freed)
}

// ============================================================================
// HELPER FUNCTION: GetFileExtension
// ============================================================================
// Description:
//   Extracts file extension from file path (lowercase, without dot).
//
// Parameters:
//   sFilePath - Full file path
//
// Returns:
//   File extension as lowercase wstring (e.g., L"png", L"jpg", L"bmp")
//   Empty string if no extension found
// ============================================================================
static std::wstring GetFileExtension(const wchar_t* sFilePath) {
	if (!sFilePath || wcslen(sFilePath) == 0) return L"";
	
	std::wstring path(sFilePath);
	size_t dotPos = path.find_last_of(L'.');
	
	if (dotPos == std::wstring::npos || dotPos == path.length() - 1) {
		return L""; // No extension or dot is last character
	}
	
	std::wstring ext = path.substr(dotPos + 1);
	
	// Convert to lowercase
	std::transform(ext.begin(), ext.end(), ext.begin(), ::towlower);
	
	return ext;
}

// ============================================================================
// EXPORTED FUNCTION: Capture_Screen_Save
// ============================================================================
// Description:
//   Captures a screen region and saves it directly to an image file.
//   Automatically detects output format from file extension.
//   Combines Capture_Screen + save functionality in one call.
//
// Parameters:
//   sImageFile - Output file path (extension determines format: .bmp, .png, .jpg/.jpeg)
//   iLeft      - Left coordinate (default: 0)
//   iTop       - Top coordinate (default: 0)
//   iRight     - Right coordinate (default: 0, full width)
//   iBottom    - Bottom coordinate (default: 0, full height)
//   iScreen    - Monitor index:
//                * iScreen < 0: Virtual screen (all monitors combined)
//                * iScreen = 0: User absolute coordinates (primary screen or multi-monitor)
//                               Supports negative coords for secondary monitors (e.g., -1920, 0)
//                               Use (0,0,0,0) for full primary screen
//                * iScreen > 0: Specific monitor (1=first, 2=second, 3=third...)
//                               Coords relative to monitor origin, (0,0,0,0) = full monitor
//
// Supported Formats:
//   - BMP  (.bmp)  - Uncompressed bitmap (default if extension not recognized)
//   - PNG  (.png)  - Lossless compression
//   - JPEG (.jpg, .jpeg) - Quality 100% (highest quality)
//
// Returns:
//   1 on success (image captured and saved)
//   0 on failure (capture failed, save failed, or invalid parameters)
//
// Notes:
//   - No need to manage HBITMAP - function handles all memory management
//   - JPEG quality is fixed at 100% for maximum quality
//   - Uses DPI-aware capture (same as Capture_Screen)
//   - Thread-safe with proper GDI+ initialization
//
// Performance:
//   - 2x faster than AutoIt GDI+ approach
//   - ~20-35ms for typical screen regions
//
// Example:
//   // Capture full primary screen to PNG
//   Capture_Screen_Save(L"screenshot.png", 0, 0, 0, 0, 0);
//
//   // Capture region (100, 100, 600, 400) on monitor 2 to JPEG
//   Capture_Screen_Save(L"region.jpg", 100, 100, 600, 400, 2);
//
//   // Capture entire virtual desktop to BMP
//   Capture_Screen_Save(L"desktop.bmp", 0, 0, 0, 0, -1);
// ============================================================================
extern "C" __declspec(dllexport) int WINAPI Capture_Screen_Save(
	const wchar_t* sImageFile,
	int iLeft = 0,
	int iTop = 0,
	int iRight = 0,
	int iBottom = 0,
	int iScreen = 0
) {
	// Validate input
	if (!sImageFile || wcslen(sImageFile) == 0) {
		return 0; // Invalid file path
	}
	
	// Initialize GDI+
	InitializeGdiplus();
	
	// Capture screen using existing internal function
	HBITMAP hBitmap = CaptureScreenInternal(iLeft, iTop, iRight, iBottom, iScreen);
	if (!hBitmap) {
		return 0; // Capture failed
	}
	
	// Extract file extension to determine format
	std::wstring ext = GetFileExtension(sImageFile);
	
	// Map extension to MIME type
	const wchar_t* mimeType = L"image/bmp"; // Default to BMP
	CLSID encoderClsid;
	
	if (ext == L"png") {
		mimeType = L"image/png";
	}
	else if (ext == L"jpg" || ext == L"jpeg") {
		mimeType = L"image/jpeg";
	}
	else if (ext == L"bmp") {
		mimeType = L"image/bmp";
	}
	// else: default to BMP for unknown extensions
	
	// Get encoder CLSID for the format
	if (GetEncoderClsid(mimeType, &encoderClsid) < 0) {
		DeleteObject(hBitmap);
		return 0; // Encoder not found
	}
	
	// Create GDI+ Bitmap from HBITMAP
	Gdiplus::Bitmap* pBitmap = Gdiplus::Bitmap::FromHBITMAP(hBitmap, NULL);
	if (!pBitmap) {
		DeleteObject(hBitmap);
		return 0; // Failed to create GDI+ bitmap
	}
	
	// Prepare encoder parameters for JPEG quality (100%)
	Gdiplus::EncoderParameters encoderParams;
	encoderParams.Count = 1;
	encoderParams.Parameter[0].Guid = Gdiplus::EncoderQuality;
	encoderParams.Parameter[0].Type = Gdiplus::EncoderParameterValueTypeLong;
	encoderParams.Parameter[0].NumberOfValues = 1;
	ULONG quality = 100L; // 100% quality
	encoderParams.Parameter[0].Value = &quality;
	
	// Save to file (use quality params only for JPEG)
	Gdiplus::Status status;
	if (ext == L"jpg" || ext == L"jpeg") {
		status = pBitmap->Save(sImageFile, &encoderClsid, &encoderParams);
	}
	else {
		status = pBitmap->Save(sImageFile, &encoderClsid, NULL);
	}
	
	// Cleanup
	delete pBitmap;
	DeleteObject(hBitmap);
	
	// Return result
	return (status == Gdiplus::Ok) ? 1 : 0;
}

// ============================================================================
// EXPORTED FUNCTION: Clear_Cache
// ============================================================================
// Description:
//   Clears all cached image locations and bitmap data.
//   Deletes both in-memory cache and persistent disk cache files.
//
// When to Use:
//   - When screen content has changed significantly
//   - Before running new test scenarios
//   - To free memory when cache grows large
//   - After display resolution changes
//
// Performance Impact:
//   After clearing cache, first searches will be slower until cache rebuilds.
//   Cache automatically validates entries, so manual clearing is rarely needed.
//
// Thread Safety:
//   Thread-safe. Acquires cache mutex before clearing.
// ============================================================================
extern "C" __declspec(dllexport) void WINAPI Clear_Cache() {
	{
		std::unique_lock<SharedMutex> lock(g_cache_mutex);
		g_location_cache_lru.clear();
		g_location_cache_index.clear();
	}

	try {
		std::wstring cache_dir = GetCacheBaseDir();
		if (!cache_dir.empty()) {
			auto entries = FileSystem::directory_iterator(cache_dir);
			for (const auto& entry : entries) {
				if (entry.is_file) {
					std::wstring filename = FileSystem::get_filename(entry.path);
					if (filename.find(L"~CACHE_IMGSEARCH_") == 0) {
						// Check if ends with .dat (C++14 compatible)
						if (filename.length() >= 4 && 
						    filename.substr(filename.length() - 4) == L".dat") {
							FileSystem::remove(entry.path);
						}
					}
				}
			}
		}
	}
	catch (...) {}

	{
		std::lock_guard<std::mutex> lock(g_bitmap_cache_mutex);
		g_bitmap_cache.clear();
	}
}

// ============================================================================
// Helper function to get monitor scale - avoid code duplication
// OPTIMIZED: Added cache to avoid repeated API calls for same monitor
// ============================================================================
static int GetMonitorScale(HMONITOR hMonitor) {
	if (!hMonitor) return 100;
	
	// OPTIMIZATION: Cache scale results per HMONITOR to avoid repeated API calls
	static std::unordered_map<HMONITOR, int> scale_cache;
	static std::mutex cache_mutex;
	
	// Check cache first
	{
		std::lock_guard<std::mutex> lock(cache_mutex);
		auto it = scale_cache.find(hMonitor);
		if (it != scale_cache.end()) {
			return it->second; // Return cached value
		}
	}
	
	int detected_scale = 100; // Default scale
	
	// Only attempt on Windows 8+
	if (g_win_ver.isWin8 || g_win_ver.isWin8_1 || g_win_ver.isWin10Plus) {
		// Define DEVICE_SCALE_FACTOR enum locally
		typedef enum {
			DEVICE_SCALE_FACTOR_INVALID = 0,
			SCALE_100_PERCENT = 100,
			SCALE_120_PERCENT = 120,
			SCALE_125_PERCENT = 125,
			SCALE_140_PERCENT = 140,
			SCALE_150_PERCENT = 150,
			SCALE_160_PERCENT = 160,
			SCALE_175_PERCENT = 175,
			SCALE_180_PERCENT = 180,
			SCALE_200_PERCENT = 200,
			SCALE_225_PERCENT = 225,
			SCALE_250_PERCENT = 250,
			SCALE_300_PERCENT = 300,
			SCALE_350_PERCENT = 350,
			SCALE_400_PERCENT = 400,
			SCALE_450_PERCENT = 450,
			SCALE_500_PERCENT = 500
		} DEVICE_SCALE_FACTOR_LOCAL;
		
		typedef HRESULT (WINAPI *PFN_GetScaleFactorForMonitor)(HMONITOR, DEVICE_SCALE_FACTOR_LOCAL*);
		
		// Static variables to cache the function pointer
		static PFN_GetScaleFactorForMonitor pGetScaleFactorForMonitor = nullptr;
		static bool initialized = false;
		
		if (!initialized) {
			HMODULE hShcore = LoadLibraryW(L"shcore.dll");
			if (hShcore) {
				pGetScaleFactorForMonitor = (PFN_GetScaleFactorForMonitor)GetProcAddress(hShcore, "GetScaleFactorForMonitor");
				// Note: We don't FreeLibrary here to keep the function pointer valid
			}
			initialized = true;
		}
		
		if (pGetScaleFactorForMonitor) {
			DEVICE_SCALE_FACTOR_LOCAL scaleFactor;
			HRESULT hr = pGetScaleFactorForMonitor(hMonitor, &scaleFactor);
			if (SUCCEEDED(hr)) {
				detected_scale = static_cast<int>(scaleFactor);
			}
		}
	}
	
	// Store in cache before returning
	{
		std::lock_guard<std::mutex> lock(cache_mutex);
		scale_cache[hMonitor] = detected_scale;
	}
	
	return detected_scale;
}

// ============================================================================
// HELPER: IsOS64Bit
// ============================================================================
// Description:
//   Detects the ACTUAL OS architecture at runtime.
//   x86 DLL can run on x64 OS via WOW64, so we need runtime detection.
//
// Returns:
//   true if OS is 64-bit, false if OS is 32-bit
//
// Logic:
//   - x64 DLL: Always running on x64 OS (return true)
//   - x86 DLL: Check IsWow64Process() to detect if running on x64 OS
// ============================================================================
static bool IsOS64Bit() {
#ifdef _WIN64
	// x64 DLL can ONLY run on x64 OS
	return true;
#else
	// x86 DLL: Check if running under WOW64 (32-bit app on 64-bit OS)
	typedef BOOL (WINAPI *LPFN_ISWOW64PROCESS)(HANDLE, PBOOL);
	
	static bool detected = false;
	static bool is_64bit = false;
	
	if (!detected) {
		HMODULE hKernel32 = GetModuleHandleW(L"kernel32.dll");
		if (hKernel32) {
			LPFN_ISWOW64PROCESS fnIsWow64Process = 
				(LPFN_ISWOW64PROCESS)GetProcAddress(hKernel32, "IsWow64Process");
			
			if (fnIsWow64Process) {
				BOOL isWow64 = FALSE;
				if (fnIsWow64Process(GetCurrentProcess(), &isWow64)) {
					is_64bit = (isWow64 == TRUE);
				}
			}
			// If IsWow64Process doesn't exist (XP x86), OS is 32-bit
		}
		detected = true;
	}
	
	return is_64bit;
#endif
}

// ============================================================================
// Get_DllInfo - Comprehensive DLL Information in INI Format
// ============================================================================
// Description:
//   Returns detailed information about DLL, OS, CPU, Screen and Cache in INI format.
//   Combines functionality of Get_Version and Get_SysInfo with enhanced details.
//
// Returns:
//   Multi-line string in INI format with sections:
//   [DLL]     - DLL name, version, architecture
//   [OS]      - OS name, version, build, platform
//   [CPU]     - Cores, threads, SIMD support
//   [SCREEN]  - Virtual screen, scale, monitors with resolutions
//   [CACHE]   - Location cache, bitmap cache, pool size
//
// Thread Safety:
//   Thread-safe. Uses thread_local storage for result buffer.
// ============================================================================
extern "C" __declspec(dllexport) const wchar_t* WINAPI Get_DllInfo() {
	// FIXED: Use dynamic string instead of fixed buffer to prevent overflow with many monitors
	thread_local std::wstring info_buffer;
	std::call_once(g_feature_detection_flag, DetectFeatures);
	DetectWindowsVersion();
	EnumerateMonitors();
	
	// Get OS name with accurate Windows 10/11 distinction
	const wchar_t* os_name = L"Unknown";
	if (g_win_ver.isWin11Plus) os_name = L"Windows 11+";
	else if (g_win_ver.isWin10) os_name = L"Windows 10";
	else if (g_win_ver.isWin8_1) os_name = L"Windows 8.1";
	else if (g_win_ver.isWin8) os_name = L"Windows 8";
	else if (g_win_ver.isWin7) os_name = L"Windows 7";
	else if (g_win_ver.isVista) os_name = L"Windows Vista";
	else if (g_win_ver.isXP) os_name = L"Windows XP";
	
	// Get CPU info
	unsigned int cpu_threads = std::thread::hardware_concurrency();
	if (cpu_threads == 0) cpu_threads = 1;
	
	// Get primary monitor scale using helper function
	HMONITOR hMonitor = MonitorFromWindow(GetDesktopWindow(), MONITOR_DEFAULTTOPRIMARY);
	int primaryScale = GetMonitorScale(hMonitor);
	
	// Build INI format string
	std::wstringstream ss;
	
	// [DLL] Section
	ss << L"[DLL]\n";
	ss << L"Name=ImageSearchDLL\n";
	ss << L"Version=3.5\n";
#ifdef _WIN64
	ss << L"Arch=x64\n";
#else
	ss << L"Arch=x86\n";
#endif
	ss << L"Author=Dao Van Trong - TRONG.PRO\n";
	ss << L"\n";
	
	// [OS] Section
	ss << L"[OS]\n";
	ss << L"Name=" << os_name << L"\n";
	ss << L"Version=" << g_win_ver.major << L"." << g_win_ver.minor << L"\n";
	ss << L"Build=" << g_win_ver.build << L"\n";
	// CORRECT: Detect ACTUAL OS architecture, not DLL architecture
	// x86 DLL can run on x64 OS via WOW64
	ss << L"Platform=" << (IsOS64Bit() ? L"x64" : L"x86") << L"\n";
	ss << L"\n";
	
	// [CPU] Section
	ss << L"[CPU]\n";
	ss << L"Threads=" << cpu_threads << L"\n";
#ifdef _WIN64
	ss << L"SSE2=Yes\n";
	ss << L"AVX2=" << (g_is_avx2_supported.load() ? L"Yes" : L"No") << L"\n";
	ss << L"AVX512=" << (g_is_avx512_supported.load() ? L"Yes" : L"No") << L"\n";
#else
	ss << L"SSE2=" << (g_is_sse2_supported.load() ? L"Yes" : L"No") << L"\n";
	ss << L"AVX2=No\n";
	ss << L"AVX512=No\n";
#endif
	ss << L"\n";
	
	 // [SCREEN] Section
	ss << L"[SCREEN]\n";
	int virt_width = GetSystemMetrics(SM_CXVIRTUALSCREEN);
	int virt_height = GetSystemMetrics(SM_CYVIRTUALSCREEN);
	ss << L"VirtualScreen=" << virt_width << L"x" << virt_height << L"\n";
	ss << L"PrimaryScale=" << primaryScale << L"%\n";
	ss << L"Monitors=" << g_monitors.size() << L"\n";
	
	// Add individual monitor resolutions and scales
	for (size_t i = 0; i < g_monitors.size(); ++i) {
		int mon_width = g_monitors[i].bounds.right - g_monitors[i].bounds.left;
		int mon_height = g_monitors[i].bounds.bottom - g_monitors[i].bounds.top;
		
		// Output resolution
		ss << L"Monitor_" << (i + 1) << L"=" << mon_width << L"x" << mon_height << L"\n";
		
		// Get monitor handle using CENTER point (more reliable for multi-monitor)
		// Using center instead of top-left+1 prevents issues with:
		// - Negative coordinates (secondary monitors on the left)
		// - Edge cases where point might be outside monitor bounds
		POINT center = { 
			(g_monitors[i].bounds.left + g_monitors[i].bounds.right) / 2,
			(g_monitors[i].bounds.top + g_monitors[i].bounds.bottom) / 2
		};
		HMONITOR hMon = MonitorFromPoint(center, MONITOR_DEFAULTTOPRIMARY);
		int monScale = 100;
		if (hMon) {
			monScale = GetMonitorScale(hMon);
		}
		
		// Output scale on separate line
		ss << L"Monitor_" << (i + 1) << L"_Scale=" << monScale << L"%";
		
		// Mark primary monitor if applicable
		if (g_monitors[i].isPrimary) {
			ss << L" (Primary)";
		}
		ss << L"\n";
	}
	ss << L"\n";
	
	// [CACHE] Section
	ss << L"[CACHE]\n";
	ss << L"LocationCache=" << g_location_cache_lru.size() << L"/" << MAX_CACHED_LOCATIONS << L"\n";
	ss << L"BitmapCache=" << g_bitmap_cache.size() << L"/" << MAX_CACHED_BITMAPS << L"\n";
	ss << L"PoolSize=" << g_pixel_pool_size.load(std::memory_order_relaxed) << L"\n";
	
	// Store in thread_local string (no size limit, prevents buffer overflow)
	info_buffer = ss.str();
	
	return info_buffer.c_str();
}


BOOL APIENTRY DllMain(HMODULE hModule, DWORD ul_reason_for_call, LPVOID lpReserved) {
	switch (ul_reason_for_call) {
	case DLL_PROCESS_ATTACH:
	{
		// Detect Windows version first
		DetectWindowsVersion();

		// REMOVED: Process-level DPI initialization
		// Reason: When loaded by AutoIt (or other GUI apps), setting process-level DPI awareness
		// causes the host application's GUI to resize unexpectedly (e.g., 125% scale → 100%).
		// 
		// Solution: DLL now uses THREAD-LOCAL DPI awareness via ScopedDpiAwareness class.
		// Each exported function that needs DPI awareness creates a ScopedDpiAwareness object,
		// which temporarily changes only the calling thread's DPI context without affecting
		// the host application's GUI or other threads.
		//
		// This approach ensures:
		// - No impact on AutoIt GUI when DLL is loaded
		// - Correct coordinate capture/click for high-DPI displays
		// - Thread-safe DPI handling
		// - Compatible with Windows XP (no-op) through Windows 11

		g_pixel_pool_size.store(CalculateOptimalPoolSize(), std::memory_order_relaxed);

#ifdef _WIN64
		g_hCacheFileMutex = CreateMutexW(nullptr, FALSE, L"Global\\ImageSearchDLL_Cache_X64");
		if (!g_hCacheFileMutex) {
			g_hCacheFileMutex = CreateMutexW(nullptr, FALSE, L"ImageSearchDLL_Cache_X64");
		}
#else
		g_hCacheFileMutex = CreateMutexW(nullptr, FALSE, L"Global\\ImageSearchDLL_Cache_x86");
		if (!g_hCacheFileMutex) {
			g_hCacheFileMutex = CreateMutexW(nullptr, FALSE, L"ImageSearchDLL_Cache_x86");
		}
#endif

		EnumerateMonitors();
		break;
	}

	case DLL_PROCESS_DETACH:
	{
		if (lpReserved == nullptr) {
			// Normal DLL unload (FreeLibrary called, but process still running)
			try {
				// Cleanup cache file mutex
				if (g_hCacheFileMutex) {
					CloseHandle(g_hCacheFileMutex);
					g_hCacheFileMutex = nullptr;
				}

				// IMPORTANT: DO NOT call GdiplusShutdown() here!
				// Reason: If host application (e.g., AutoIt) or other DLLs are still using GDI+,
				//         calling GdiplusShutdown() will crash the entire application!
				// GDI+ is a system-wide resource shared across the process.
				// Only reset token to prevent double-shutdown.
				if (g_gdiplusToken != 0) {
					g_gdiplusToken = 0;  // Just mark as uninitialized
				}
			}
			catch (...) {
				// Ignore exceptions during cleanup
			}
		}
		else {
			// Process termination - OS will cleanup everything automatically
			g_gdiplusToken = 0;
		}

		break;
	}

	case DLL_THREAD_ATTACH:
	case DLL_THREAD_DETACH:
		break;
	}
	return TRUE;
}

#pragma managed(pop)

/*
 * ----------------------------------------------------------------------------
 *  MIT License
 *  Copyright (c) 2025 Dao Van Trong - TRONG.PRO
 *
 *  Permission is hereby granted, free of charge, to any person obtaining a copy
 *  of this software and associated documentation files (the "Software"), to deal
 *  in the Software without restriction, including without limitation the rights
 *  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 *  copies of the Software, and to permit persons to whom the Software is
 *  furnished to do so, subject to the following conditions:
 *
 *  The above copyright notice and this permission notice shall be included in all
 *  copies or substantial portions of the Software.
 *
 *  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 *  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 *  SOFTWARE.
 * ----------------------------------------------------------------------------
 */
