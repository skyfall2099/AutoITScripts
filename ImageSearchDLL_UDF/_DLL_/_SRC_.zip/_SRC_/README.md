# ImageSearchDLL - Ultra-Fast Image Search Engine

High-performance C++ DLL for image searching with SIMD optimization and multi-monitor support.

## Overview

ImageSearchDLL is a native Windows C++ library that provides ultra-fast image search capabilities using advanced SIMD instructions (AVX512/AVX2/SSE2). Built with C++14 and optimized for performance, it supports Windows XP SP3 through Windows 11 on both x86 and x64 architectures.

## Features

### 🚀 **Performance Optimizations**
- **SIMD Instructions**: AVX512/AVX2/SSE2 for parallel pixel processing
- **Multi-threading**: Parallel search across multiple CPU cores
- **Cache System**: LRU cache for bitmap and location data
- **Memory Pool**: Efficient memory management for large images
- **Thread-local Storage**: Minimizes synchronization overhead

### 🖥️ **Multi-Monitor Support**
- **Virtual Desktop**: Full support for multi-monitor setups
- **DPI Awareness**: Thread-local DPI awareness without GUI side effects
- **Negative Coordinates**: Proper handling of secondary monitor positioning
- **Per-Monitor Scaling**: Individual DPI scale detection for each monitor

### 🎯 **Advanced Search Capabilities**
- **Image Scaling**: Search at multiple scales (0.1x to 5.0x)
- **Color Tolerance**: Configurable tolerance for color matching (0-255)
- **Multiple Results**: Return up to 1024 matches per search
- **Region Search**: Limit search to specific screen areas
- **Format Support**: BMP, PNG, JPG, and other GDI+ supported formats

### 📸 **Screen Capture**
- **Direct Capture**: Fast screen-to-file saving without intermediate steps
- **Format Detection**: Automatic format selection based on file extension
- **DPI-Aware**: Accurate capture on high-DPI displays
- **Memory Efficient**: Minimal memory footprint during capture

## Architecture

### **Compilation Requirements**
- **Compiler**: Visual Studio 2017+ 
- **Platform Toolset**: v141_xp (Windows XP SP3+ compatibility)
- **Windows SDK**: 7.1A (used by v141_xp toolset for XP compatibility)
- **C++ Standard**: C++14 (stdcpp14)
- **Target Platforms**: x86, x64

### **Dependencies**
```cpp
// Core Windows APIs
#include <windows.h>
#include <gdiplus.h>
#include <shlwapi.h>

// SIMD Support
#ifdef _WIN64
#include <immintrin.h>  // AVX512/AVX2
#else
#include <emmintrin.h>  // SSE2
#endif

// Standard Library
#include <algorithm>
#include <vector>
#include <memory>
#include <thread>
#include <mutex>
#include <atomic>
#include <unordered_map>
```

### **Linked Libraries**
- `kernel32.lib` - Core Windows functions
- `user32.lib` - User interface functions
- `gdi32.lib` - Graphics Device Interface
- `gdiplus.lib` - GDI+ graphics library
- `shell32.lib` - Shell functions
- `shlwapi.lib` - Shell lightweight utility functions
- `ole32.lib` - OLE functions
- `oleaut32.lib` - OLE automation
- `uuid.lib` - UUID functions

## API Reference

### Core Search Functions

#### `ImageSearch`
```cpp
extern "C" __declspec(dllexport) const wchar_t* WINAPI ImageSearch(
    const wchar_t* sImageFile,
    int iLeft = 0,
    int iTop = 0,
    int iRight = 0,
    int iBottom = 0,
    int iScreen = -1,
    int iTolerance = 10,
    int iResults = 1,
    int iCenterPOS = 1,
    float fMinScale = 1.0f,
    float fMaxScale = 1.0f,
    float fScaleStep = 0.1f,
    int iReturnDebug = 0,
    int iUseCache = 1
);
```

**Description:** Primary image search function for finding images on screen.

**Parameters:**
- `sImageFile` - Path to target image file(s), pipe-separated for multiple images
- `iLeft, iTop, iRight, iBottom` - Search region coordinates (0 = full screen)
- `iScreen` - Monitor selection (-1=virtual, 0=primary, 1+=specific monitor)
- `iTolerance` - Color matching tolerance (0-255)
- `iResults` - Maximum number of results to return (1-1024)
- `iCenterPOS` - Return center coordinates (1) or top-left (0)
- `fMinScale, fMaxScale` - Scale range for multi-scale search
- `fScaleStep` - Scale increment step
- `iReturnDebug` - Enable debug information in result
- `iUseCache` - Enable caching for performance

**Returns:** Wide string with search results in format: `{count}[x|y|w|h,...]`

#### `Search_In_Image`
```cpp
extern "C" __declspec(dllexport) const wchar_t* WINAPI Search_In_Image(
    const wchar_t* sSourceImageFile,
    const wchar_t* sTargetImageFile,
    int iTolerance = 10,
    int iResults = 1,
    int iCenterPOS = 1,
    float fMinScale = 1.0f,
    float fMaxScale = 1.0f,
    float fScaleStep = 0.1f,
    int iReturnDebug = 0,
    int iUseCache = 0
);
```

**Description:** Search for target image within source image file (file-to-file search).

#### `hBitmap_Search`
```cpp
extern "C" __declspec(dllexport) const wchar_t* WINAPI hBitmap_Search(
    HBITMAP hBitmapSource,
    HBITMAP hBitmapTarget,
    int iTolerance,
    int iLeft,
    int iTop,
    int iRight,
    int iBottom,
    int iResults,
    int iCenterPOS,
    float fMinScale,
    float fMaxScale,
    float fScaleStep,
    int iReturnDebug,
    int iUseCache
);
```

**Description:** Search for target bitmap within source bitmap (memory-to-memory search).

### Screen Capture Functions

#### `Capture_Screen`
```cpp
extern "C" __declspec(dllexport) HBITMAP WINAPI Capture_Screen(
    int iLeft = 0,
    int iTop = 0,
    int iRight = 0,
    int iBottom = 0,
    int iScreen = -1
);
```

**Description:** Capture screen region and return HBITMAP handle.

#### `Capture_Screen_Save`
```cpp
extern "C" __declspec(dllexport) int WINAPI Capture_Screen_Save(
    const wchar_t* sImageFile,
    int iLeft = 0,
    int iTop = 0,
    int iRight = 0,
    int iBottom = 0,
    int iScreen = 0
);
```

**Description:** Capture screen region and save directly to file (2x faster than separate operations).

#### `hBitmap_Load`
```cpp
extern "C" __declspec(dllexport) HBITMAP WINAPI hBitmap_Load(
    const wchar_t* sImageFile,
    int iAlpha = 0,
    int iRed = 0,
    int iGreen = 0,
    int iBlue = 0
);
```

**Description:** Load image file and convert to HBITMAP with optional background color.

### Mouse Functions

#### `Mouse_Click`
```cpp
extern "C" __declspec(dllexport) int WINAPI Mouse_Click(
    const wchar_t* sButton,
    int iX,
    int iY,
    int iClicks,
    int iSpeed,
    int iScreen
);
```

**Description:** Perform mouse click with DPI-aware coordinates and multi-monitor support.

#### `Mouse_Move`
```cpp
extern "C" __declspec(dllexport) int WINAPI Mouse_Move(
    int iX,
    int iY,
    int iSpeed,
    int iScreen
);
```

**Description:** Move mouse cursor with smooth movement and multi-monitor support.

#### `Mouse_ClickWin`
```cpp
extern "C" __declspec(dllexport) int WINAPI Mouse_ClickWin(
    const wchar_t* sTitle,
    const wchar_t* sText,
    int iX,
    int iY,
    const wchar_t* sButton,
    int iClicks,
    int iSpeed
);
```

**Description:** Click at coordinates relative to a specific window.

### System Information Functions

#### `Get_DllInfo`
```cpp
extern "C" __declspec(dllexport) const wchar_t* WINAPI Get_DllInfo();
```

**Description:** Get comprehensive system information including:
- DLL version, architecture, and build info
- Operating system details and version
- CPU capabilities (SSE2, AVX2, AVX512)
- Monitor configuration and DPI scaling
- Cache status and memory usage

**Returns:** Multi-line INI-format string with detailed system information.

### Cache Management

#### `Clear_Cache`
```cpp
extern "C" __declspec(dllexport) void WINAPI Clear_Cache();
```

**Description:** Clear all cached bitmaps and location data to free memory.

## Build Configuration

### Project Settings
- **Configuration Type**: Dynamic Library (.dll)
- **Platform Toolset**: v141_xp (Visual Studio 2017 with XP support)
- **Character Set**: Unicode
- **Windows Target Platform**: 10.0
- **C++ Language Standard**: C++14

### Compiler Optimizations
- **Release Mode**: Whole Program Optimization enabled
- **SIMD**: Automatic vectorization with SSE2/AVX2/AVX512
- **Memory**: Optimized memory allocation and deallocation
- **Threading**: Lock-free algorithms where possible

### Preprocessor Definitions
```cpp
#define NOMINMAX                    // Prevent min/max macro conflicts
#define _WIN32_IE 0x0500           // Internet Explorer 5.0+ features
#define _WIN32_WINNT 0x0502        // Windows XP SP2+ features
```

## Performance Characteristics

### **Benchmark Results** (Typical scenarios)
- **Single Image Search**: 1-5ms on 1920x1080 screen
- **Multi-Scale Search**: 5-20ms depending on scale range
- **Screen Capture**: 2-8ms for full screen
- **Cache Hit**: 50-80% faster than cold search
- **Multi-threading**: 2-4x speedup on multi-core systems

### **Memory Usage**
- **Base DLL**: ~2MB loaded in memory
- **Cache System**: Configurable, typically 50-200MB
- **Per Search**: 10-50MB temporary allocation
- **Screen Capture**: Width × Height × 4 bytes

### **SIMD Optimization Levels**
1. **SSE2**: Available on all x64 and most x86 systems (4x parallel)
2. **AVX2**: Modern CPUs 2013+ (8x parallel)
3. **AVX512**: High-end CPUs 2017+ (16x parallel)

## Error Codes

| Code | Description |
|------|-------------|
| -1 | Invalid file path or file not found |
| -2 | Failed to load image (corrupt or unsupported format) |
| -3 | Failed to get screen device context |
| -4 | Invalid search region coordinates |
| -5 | Invalid function parameters |
| -6 | Invalid source bitmap handle |
| -7 | Invalid target bitmap handle |
| -9 | Result buffer too large |
| -10 | Invalid monitor index |

## Thread Safety

The DLL is designed to be thread-safe with the following considerations:

- **Search Functions**: Fully thread-safe, can be called from multiple threads
- **Cache System**: Protected by shared mutex, supports concurrent reads
- **GDI+ Operations**: Thread-local initialization prevents conflicts
- **Result Buffers**: Thread-local storage eliminates race conditions
- **System Info**: Cached after first call, thread-safe access

## Windows Compatibility

### **Supported Versions**
- ✅ Windows XP SP3 (x86/x64)
- ✅ Windows Vista (x86/x64)
- ✅ Windows 7 (x86/x64)
- ✅ Windows 8/8.1 (x86/x64)
- ✅ Windows 10 (x86/x64)
- ✅ Windows 11 (x86/x64)

### **Feature Availability**
- **DPI Awareness**: Windows 8.1+ (graceful fallback on older versions)
- **Multi-Monitor**: All versions (enhanced features on Windows 7+)
- **SIMD Instructions**: CPU-dependent, automatic detection
- **Thread-local DPI**: Windows 10 Anniversary Update+ (v1607)

## Development Notes

### **Code Organization**
```
ImageSearchDLL.cpp
├── Headers & Dependencies (lines 1-100)
├── Windows Version Detection (lines 100-200)
├── SIMD Feature Detection (lines 200-400)
├── Cache System Implementation (lines 400-800)
├── Image Processing Core (lines 800-2000)
├── Search Algorithms (lines 2000-3000)
├── Screen Capture Functions (lines 3000-3500)
├── Mouse Functions (lines 3500-4000)
├── System Information (lines 4000-4200)
└── DLL Entry Point (lines 4200-4320)
```

### **Key Design Patterns**
- **RAII**: Automatic resource management for GDI objects
- **Thread-local Storage**: Eliminates synchronization overhead
- **Template Metaprogramming**: Compile-time SIMD selection
- **Cache-friendly Algorithms**: Optimized memory access patterns
- **Exception Safety**: Strong exception safety guarantees

## License

```
MIT License
Copyright (c) 2025 Dao Van Trong - TRONG.PRO

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```

## Author

**Dao Van Trong** - [TRONG.PRO](https://trong.pro)

---

*Built with ❤️ for the AutoIt community and high-performance image processing applications.*
